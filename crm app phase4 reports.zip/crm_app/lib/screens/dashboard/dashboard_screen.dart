import 'package:flutter/material.dart';
import '../../services/database_service.dart';
import '../../utils/app_theme.dart';
import '../../services/database_service.dart';

class DashboardScreen extends StatefulWidget {
  const DashboardScreen({super.key});

  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  int _clientCount = 0;
  int _quotationCount = 0;
  int _invoiceCount = 0;
  double _totalRevenue = 0;
  double _pendingAmount = 0;
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _loadStats();
  }

  Future<void> _loadStats() async {
    final clients = await DatabaseService.instance.getAllClients();
    final quotations = await DatabaseService.instance.getAllQuotations();
    final invoices = await DatabaseService.instance.getAllInvoices();

    double revenue = 0;
    double pending = 0;
    for (final inv in invoices) {
      if (inv['status'] == 'paid') revenue += (inv['total'] as num).toDouble();
      if (inv['status'] == 'unpaid') pending += (inv['total'] as num).toDouble();
    }

    setState(() {
      _clientCount = clients.length;
      _quotationCount = quotations.length;
      _invoiceCount = invoices.length;
      _totalRevenue = revenue;
      _pendingAmount = pending;
      _isLoading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        titleSpacing: 12,
        title: Row(
          children: [
            Container(
              height: 34,
              width: 76,
              decoration: BoxDecoration(
                color: const Color(0xFF3A3A3A),
                borderRadius: BorderRadius.circular(8),
              ),
              padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 4),
              child: Image.asset('assets/images/logo.png', fit: BoxFit.contain),
            ),
            const SizedBox(width: 10),
            const Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('TECH SPWORLD', style: TextStyle(fontSize: 13, fontWeight: FontWeight.bold, letterSpacing: 1, color: Colors.white)),
                Text('CRM PORTAL', style: TextStyle(fontSize: 9, color: Colors.white70, letterSpacing: 2)),
              ],
            ),
          ],
        ),
        actions: [
          IconButton(icon: const Icon(Icons.refresh), onPressed: _loadStats),
        ],
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : RefreshIndicator(
              onRefresh: _loadStats,
              child: SingleChildScrollView(
                physics: const AlwaysScrollableScrollPhysics(),
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // Welcome
                    const Text(
                      'Welcome back! 👋',
                      style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold, color: AppTheme.textDark),
                    ),
                    const Text('Here\'s your business overview', style: TextStyle(color: AppTheme.textGrey)),
                    const SizedBox(height: 20),

                    // Revenue Cards
                    Row(
                      children: [
                        Expanded(child: _revenueCard('Total Revenue', _totalRevenue, Icons.trending_up, AppTheme.accent)),
                        const SizedBox(width: 12),
                        Expanded(child: _revenueCard('Pending', _pendingAmount, Icons.schedule, AppTheme.warning)),
                      ],
                    ),

                    const SizedBox(height: 16),

                    // Stats Grid
                    GridView.count(
                      shrinkWrap: true,
                      physics: const NeverScrollableScrollPhysics(),
                      crossAxisCount: 3,
                      crossAxisSpacing: 12,
                      mainAxisSpacing: 12,
                      childAspectRatio: 1.1,
                      children: [
                        _statCard('Clients', _clientCount.toString(), Icons.people, AppTheme.primary),
                        _statCard('Quotations', _quotationCount.toString(), Icons.description, AppTheme.secondary),
                        _statCard('Invoices', _invoiceCount.toString(), Icons.receipt, Colors.purple),
                      ],
                    ),

                    const SizedBox(height: 24),

                    // Quick Actions
                    const Text('Quick Actions', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: AppTheme.textDark)),
                    const SizedBox(height: 12),
                    Row(
                      children: [
                        _quickAction(Icons.person_add, 'Add Client', AppTheme.primary, () {}),
                        const SizedBox(width: 12),
                        _quickAction(Icons.description, 'Quotation', AppTheme.secondary, () {}),
                        const SizedBox(width: 12),
                        _quickAction(Icons.receipt, 'Invoice', AppTheme.accent, () {}),
                        const SizedBox(width: 12),
                        _quickAction(Icons.money_off, 'Expense', AppTheme.warning, () {}),
                      ],
                    ),

                    const SizedBox(height: 24),

                    // Tips
                    Container(
                      padding: const EdgeInsets.all(16),
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          colors: [AppTheme.primary, AppTheme.secondary],
                          begin: Alignment.topLeft,
                          end: Alignment.bottomRight,
                        ),
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: Row(
                        children: [
                          const Icon(Icons.lightbulb_outline, color: Colors.white, size: 32),
                          const SizedBox(width: 12),
                          const Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text('Tip', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
                                Text(
                                  'Go to Reports tab to see your monthly revenue, expenses and profit/loss!',
                                  style: TextStyle(color: Colors.white70, fontSize: 12),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
    );
  }

  Widget _revenueCard(String title, double amount, IconData icon, Color color) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: color.withOpacity(0.1),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: color.withOpacity(0.3)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(icon, color: color, size: 24),
          const SizedBox(height: 8),
          Text(
            '₹${amount.toStringAsFixed(0)}',
            style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: color),
          ),
          Text(title, style: const TextStyle(color: AppTheme.textGrey, fontSize: 12)),
        ],
      ),
    );
  }

  Widget _statCard(String label, String value, IconData icon, Color color) {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.05), blurRadius: 8)],
      ),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(icon, color: color, size: 28),
          const SizedBox(height: 6),
          Text(value, style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold, color: color)),
          Text(label, style: const TextStyle(color: AppTheme.textGrey, fontSize: 11), textAlign: TextAlign.center),
        ],
      ),
    );
  }

  Widget _quickAction(IconData icon, String label, Color color, VoidCallback onTap) {
    return Expanded(
      child: GestureDetector(
        onTap: onTap,
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 12),
          decoration: BoxDecoration(
            color: color.withOpacity(0.1),
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: color.withOpacity(0.3)),
          ),
          child: Column(
            children: [
              Icon(icon, color: color, size: 24),
              const SizedBox(height: 4),
              Text(label, style: TextStyle(color: color, fontSize: 10, fontWeight: FontWeight.w600), textAlign: TextAlign.center),
            ],
          ),
        ),
      ),
    );
  }
}
