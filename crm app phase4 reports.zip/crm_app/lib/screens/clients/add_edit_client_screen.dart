import 'package:flutter/material.dart';
import 'package:uuid/uuid.dart';
import '../../models/client.dart';
import '../../services/database_service.dart';
import '../../utils/app_theme.dart';

class AddEditClientScreen extends StatefulWidget {
  final Client? client;
  const AddEditClientScreen({super.key, this.client});

  @override
  State<AddEditClientScreen> createState() => _AddEditClientScreenState();
}

class _AddEditClientScreenState extends State<AddEditClientScreen> {
  final _formKey = GlobalKey<FormState>();
  final _nameController = TextEditingController();
  final _emailController = TextEditingController();
  final _phoneController = TextEditingController();
  final _addressController = TextEditingController();
  final _cityController = TextEditingController();
  final _pincodeController = TextEditingController();
  final _gstinController = TextEditingController();
  final _companyController = TextEditingController();
  String _selectedState = 'Maharashtra';
  bool _isSaving = false;

  bool get _isEditing => widget.client != null;

  @override
  void initState() {
    super.initState();
    if (_isEditing) {
      final c = widget.client!;
      _nameController.text = c.name;
      _emailController.text = c.email;
      _phoneController.text = c.phone;
      _addressController.text = c.address;
      _cityController.text = c.city;
      _pincodeController.text = c.pincode;
      _gstinController.text = c.gstin ?? '';
      _companyController.text = c.companyName ?? '';
      _selectedState = c.state;
    }
  }

  Future<void> _save() async {
    if (!_formKey.currentState!.validate()) return;
    setState(() => _isSaving = true);

    final client = Client(
      id: _isEditing ? widget.client!.id : const Uuid().v4(),
      name: _nameController.text.trim(),
      email: _emailController.text.trim(),
      phone: _phoneController.text.trim(),
      address: _addressController.text.trim(),
      city: _cityController.text.trim(),
      state: _selectedState,
      pincode: _pincodeController.text.trim(),
      gstin: _gstinController.text.trim().isEmpty ? null : _gstinController.text.trim(),
      companyName: _companyController.text.trim().isEmpty ? null : _companyController.text.trim(),
      createdAt: _isEditing ? widget.client!.createdAt : DateTime.now(),
    );

    if (_isEditing) {
      await DatabaseService.instance.updateClient(client);
    } else {
      await DatabaseService.instance.createClient(client);
    }

    if (mounted) {
      Navigator.pop(context);
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(_isEditing ? 'Client updated!' : 'Client added!'),
          backgroundColor: AppTheme.accent,
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(_isEditing ? 'Edit Client' : 'Add Client'),
      ),
      body: Form(
        key: _formKey,
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _sectionTitle('Basic Information'),
              const SizedBox(height: 12),
              _buildField(_nameController, 'Full Name *', Icons.person, required: true),
              const SizedBox(height: 12),
              _buildField(_companyController, 'Company Name', Icons.business),
              const SizedBox(height: 12),
              _buildField(_phoneController, 'Phone Number *', Icons.phone, required: true, keyboardType: TextInputType.phone),
              const SizedBox(height: 12),
              _buildField(_emailController, 'Email Address *', Icons.email, required: true, keyboardType: TextInputType.emailAddress),
              
              const SizedBox(height: 24),
              _sectionTitle('Address'),
              const SizedBox(height: 12),
              _buildField(_addressController, 'Street Address *', Icons.location_on, required: true, maxLines: 2),
              const SizedBox(height: 12),
              Row(
                children: [
                  Expanded(child: _buildField(_cityController, 'City *', Icons.location_city, required: true)),
                  const SizedBox(width: 12),
                  Expanded(child: _buildField(_pincodeController, 'Pincode *', Icons.pin_drop, required: true, keyboardType: TextInputType.number)),
                ],
              ),
              const SizedBox(height: 12),
              _buildStateDropdown(),

              const SizedBox(height: 24),
              _sectionTitle('GST Information (Optional)'),
              const SizedBox(height: 12),
              _buildField(_gstinController, 'GSTIN', Icons.receipt_long),

              const SizedBox(height: 32),
              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: _isSaving ? null : _save,
                  child: _isSaving
                      ? const SizedBox(height: 20, width: 20, child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2))
                      : Text(_isEditing ? 'Update Client' : 'Add Client', style: const TextStyle(fontSize: 16)),
                ),
              ),
              const SizedBox(height: 20),
            ],
          ),
        ),
      ),
    );
  }

  Widget _sectionTitle(String title) {
    return Text(
      title,
      style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: AppTheme.primary),
    );
  }

  Widget _buildField(
    TextEditingController controller,
    String label,
    IconData icon, {
    bool required = false,
    TextInputType keyboardType = TextInputType.text,
    int maxLines = 1,
  }) {
    return TextFormField(
      controller: controller,
      keyboardType: keyboardType,
      maxLines: maxLines,
      decoration: InputDecoration(
        labelText: label,
        prefixIcon: Icon(icon, color: AppTheme.primary, size: 20),
      ),
      validator: required
          ? (value) => (value == null || value.trim().isEmpty) ? '$label is required' : null
          : null,
    );
  }

  Widget _buildStateDropdown() {
    return DropdownButtonFormField<String>(
      value: _selectedState,
      decoration: const InputDecoration(
        labelText: 'State *',
        prefixIcon: Icon(Icons.map, color: AppTheme.primary, size: 20),
      ),
      items: AppConstants.indianStates.map((state) {
        return DropdownMenuItem(value: state, child: Text(state));
      }).toList(),
      onChanged: (value) => setState(() => _selectedState = value!),
    );
  }
}

class AppConstants {
  static const List<String> indianStates = [
    'Andhra Pradesh', 'Arunachal Pradesh', 'Assam', 'Bihar', 'Chhattisgarh',
    'Goa', 'Gujarat', 'Haryana', 'Himachal Pradesh', 'Jharkhand', 'Karnataka',
    'Kerala', 'Madhya Pradesh', 'Maharashtra', 'Manipur', 'Meghalaya', 'Mizoram',
    'Nagaland', 'Odisha', 'Punjab', 'Rajasthan', 'Sikkim', 'Tamil Nadu',
    'Telangana', 'Tripura', 'Uttar Pradesh', 'Uttarakhand', 'West Bengal',
    'Delhi', 'Jammu & Kashmir', 'Ladakh', 'Chandigarh', 'Puducherry',
  ];
}
