import 'package:flutter/material.dart';
import '../../models/client.dart';
import '../../services/database_service.dart';
import '../../utils/app_theme.dart';
import 'add_edit_client_screen.dart';

class ClientDetailScreen extends StatefulWidget {
  final Client client;
  const ClientDetailScreen({super.key, required this.client});

  @override
  State<ClientDetailScreen> createState() => _ClientDetailScreenState();
}

class _ClientDetailScreenState extends State<ClientDetailScreen> {
  late Client _client;
  List<Map<String, dynamic>> _quotations = [];
  List<Map<String, dynamic>> _invoices = [];

  @override
  void initState() {
    super.initState();
    _client = widget.client;
    _loadData();
  }

  Future<void> _loadData() async {
    final quotations = await DatabaseService.instance.getClientQuotations(_client.id!);
    final db = await DatabaseService.instance.database;
    final invoices = await db.query('invoices', where: 'clientId = ?', whereArgs: [_client.id], orderBy: 'createdAt DESC');
    setState(() {
      _quotations = quotations;
      _invoices = invoices;
    });
  }

  Future<void> _deleteClient() async {
    final confirm = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Delete Client'),
        content: Text('Are you sure you want to delete ${_client.name}? This cannot be undone.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancel')),
          TextButton(
            onPressed: () => Navigator.pop(ctx, true),
            child: const Text('Delete', style: TextStyle(color: AppTheme.danger)),
          ),
        ],
      ),
    );

    if (confirm == true) {
      await DatabaseService.instance.deleteClient(_client.id!);
      if (mounted) Navigator.pop(context);
    }
  }

  @override
  Widget build(BuildContext context) {
    final initials = _client.name.split(' ').map((e) => e.isNotEmpty ? e[0] : '').take(2).join().toUpperCase();

    return Scaffold(
      appBar: AppBar(
        title: const Text('Client Details'),
        actions: [
          IconButton(
            icon: const Icon(Icons.edit),
            onPressed: () async {
              await Navigator.push(context, MaterialPageRoute(
                builder: (_) => AddEditClientScreen(client: _client),
              ));
              final updated = await DatabaseService.instance.getClient(_client.id!);
              if (updated != null) setState(() => _client = updated);
            },
          ),
          IconButton(
            icon: const Icon(Icons.delete),
            onPressed: _deleteClient,
          ),
        ],
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            // Header
            Container(
              color: AppTheme.primary,
              padding: const EdgeInsets.only(bottom: 24),
              width: double.infinity,
              child: Column(
                children: [
                  const SizedBox(height: 16),
                  CircleAvatar(
                    radius: 40,
                    backgroundColor: Colors.white.withOpacity(0.2),
                    child: Text(initials, style: const TextStyle(fontSize: 28, color: Colors.white, fontWeight: FontWeight.bold)),
                  ),
                  const SizedBox(height: 12),
                  Text(_client.name, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: Colors.white)),
                  if (_client.companyName != null)
                    Text(_client.companyName!, style: TextStyle(color: Colors.white.withOpacity(0.8))),
                ],
              ),
            ),

            Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Stats Row
                  Row(
                    children: [
                      _statCard('Quotations', _quotations.length.toString(), Icons.description, AppTheme.secondary),
                      const SizedBox(width: 12),
                      _statCard('Invoices', _invoices.length.toString(), Icons.receipt, AppTheme.accent),
                    ],
                  ),

                  const SizedBox(height: 20),

                  // Contact Info
                  _infoCard('Contact Information', [
                    _infoRow(Icons.phone, 'Phone', _client.phone),
                    _infoRow(Icons.email, 'Email', _client.email),
                  ]),

                  const SizedBox(height: 16),

                  // Address
                  _infoCard('Address', [
                    _infoRow(Icons.location_on, 'Address', '${_client.address}, ${_client.city}, ${_client.state} - ${_client.pincode}'),
                  ]),

                  if (_client.gstin != null) ...[
                    const SizedBox(height: 16),
                    _infoCard('GST Information', [
                      _infoRow(Icons.receipt_long, 'GSTIN', _client.gstin!),
                    ]),
                  ],

                  const SizedBox(height: 16),

                  // Quick Actions
                  Row(
                    children: [
                      Expanded(
                        child: ElevatedButton.icon(
                          icon: const Icon(Icons.description, size: 18),
                          label: const Text('New Quotation'),
                          onPressed: () {
                            // Navigate to quotation creation
                            ScaffoldMessenger.of(context).showSnackBar(
                              const SnackBar(content: Text('Quotation feature coming in Phase 2!')),
                            );
                          },
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: ElevatedButton.icon(
                          icon: const Icon(Icons.receipt, size: 18),
                          label: const Text('New Invoice'),
                          style: ElevatedButton.styleFrom(backgroundColor: AppTheme.accent),
                          onPressed: () {
                            ScaffoldMessenger.of(context).showSnackBar(
                              const SnackBar(content: Text('Invoice feature coming in Phase 3!')),
                            );
                          },
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _statCard(String label, String value, IconData icon, Color color) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: color.withOpacity(0.1),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: color.withOpacity(0.3)),
        ),
        child: Row(
          children: [
            Icon(icon, color: color, size: 28),
            const SizedBox(width: 12),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(value, style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: color)),
                Text(label, style: const TextStyle(color: AppTheme.textGrey, fontSize: 12)),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _infoCard(String title, List<Widget> children) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(title, style: const TextStyle(fontSize: 14, fontWeight: FontWeight.bold, color: AppTheme.primary)),
            const Divider(),
            ...children,
          ],
        ),
      ),
    );
  }

  Widget _infoRow(IconData icon, String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(icon, size: 18, color: AppTheme.textGrey),
          const SizedBox(width: 8),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(label, style: const TextStyle(fontSize: 11, color: AppTheme.textGrey)),
                Text(value, style: const TextStyle(color: AppTheme.textDark)),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
