import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../../models/expense.dart';
import '../../services/database_service.dart';
import '../../utils/app_theme.dart';
import '../expenses/add_expense_screen.dart';

class ReportsScreen extends StatefulWidget {
  const ReportsScreen({super.key});

  @override
  State<ReportsScreen> createState() => _ReportsScreenState();
}

class _ReportsScreenState extends State<ReportsScreen> with SingleTickerProviderStateMixin {
  late TabController _tabController;
  bool _isLoading = true;

  // Filter
  int _selectedYear = DateTime.now().year;
  int _selectedMonth = DateTime.now().month;
  bool _showAllMonths = false;

  // Data
  List<Map<String, dynamic>> _invoices = [];
  List<Map<String, dynamic>> _expenses = [];
  List<Map<String, dynamic>> _quotations = [];

  final formatter = NumberFormat('#,##,##0.00', 'en_IN');

  // ── Computed values ──────────────────────────────────────────────────────────
  List<Map<String, dynamic>> get _filteredInvoices => _invoices.where((inv) {
    final d = DateTime.parse(inv['date']);
    return _showAllMonths ? d.year == _selectedYear : d.year == _selectedYear && d.month == _selectedMonth;
  }).toList();

  List<Map<String, dynamic>> get _filteredExpenses => _expenses.where((e) {
    final d = DateTime.parse(e['date']);
    return _showAllMonths ? d.year == _selectedYear : d.year == _selectedYear && d.month == _selectedMonth;
  }).toList();

  double get _totalRevenue => _filteredInvoices.where((i) => i['status'] == 'paid').fold(0, (s, i) => s + (i['total'] as num).toDouble());
  double get _totalPending => _filteredInvoices.where((i) => i['status'] == 'unpaid' || i['status'] == 'overdue').fold(0, (s, i) => s + (i['total'] as num).toDouble());
  double get _totalInvoiced => _filteredInvoices.where((i) => i['status'] != 'cancelled').fold(0, (s, i) => s + (i['total'] as num).toDouble());
  double get _totalExpenses => _filteredExpenses.fold(0, (s, e) => s + (e['amount'] as num).toDouble());
  double get _netProfit => _totalRevenue - _totalExpenses;

  // Monthly breakdown (12 months of selected year)
  List<Map<String, dynamic>> get _monthlyData {
    final months = List.generate(12, (i) {
      final m = i + 1;
      final inv = _invoices.where((x) {
        final d = DateTime.parse(x['date']);
        return d.year == _selectedYear && d.month == m && x['status'] == 'paid';
      }).fold(0.0, (s, x) => s + (x['total'] as num).toDouble());
      final exp = _expenses.where((x) {
        final d = DateTime.parse(x['date']);
        return d.year == _selectedYear && d.month == m;
      }).fold(0.0, (s, x) => s + (x['amount'] as num).toDouble());
      return {'month': m, 'revenue': inv, 'expenses': exp, 'profit': inv - exp};
    });
    return months;
  }

  // Expense by category
  Map<String, double> get _expenseByCategory {
    final map = <String, double>{};
    for (final e in _filteredExpenses) {
      final cat = e['category'] as String;
      map[cat] = (map[cat] ?? 0) + (e['amount'] as num).toDouble();
    }
    final sorted = Map.fromEntries(map.entries.toList()..sort((a, b) => b.value.compareTo(a.value)));
    return sorted;
  }

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 3, vsync: this);
    _loadData();
  }

  Future<void> _loadData() async {
    setState(() => _isLoading = true);
    final invoices = await DatabaseService.instance.getAllInvoices();
    final expenses = await DatabaseService.instance.getAllExpenses();
    final quotations = await DatabaseService.instance.getAllQuotations();
    setState(() {
      _invoices = invoices;
      _expenses = expenses;
      _quotations = quotations;
      _isLoading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Reports & Analytics'),
        actions: [
          IconButton(icon: const Icon(Icons.add), tooltip: 'Add Expense', onPressed: () async {
            await Navigator.push(context, MaterialPageRoute(builder: (_) => const AddExpenseScreen()));
            _loadData();
          }),
          IconButton(icon: const Icon(Icons.refresh), onPressed: _loadData),
        ],
        bottom: TabBar(
          controller: _tabController,
          indicatorColor: Colors.white,
          labelColor: Colors.white,
          unselectedLabelColor: Colors.white60,
          tabs: const [
            Tab(icon: Icon(Icons.bar_chart, size: 18), text: 'Overview'),
            Tab(icon: Icon(Icons.receipt_long, size: 18), text: 'Sales'),
            Tab(icon: Icon(Icons.money_off, size: 18), text: 'Expenses'),
          ],
        ),
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : Column(
              children: [
                // Filter bar
                _buildFilterBar(),
                Expanded(
                  child: TabBarView(
                    controller: _tabController,
                    children: [
                      _buildOverviewTab(),
                      _buildSalesTab(),
                      _buildExpensesTab(),
                    ],
                  ),
                ),
              ],
            ),
    );
  }

  // ── Filter Bar ───────────────────────────────────────────────────────────────
  Widget _buildFilterBar() {
    final months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    return Container(
      color: Colors.white,
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              // Year selector
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                decoration: BoxDecoration(color: AppTheme.primary.withOpacity(0.1), borderRadius: BorderRadius.circular(20)),
                child: DropdownButtonHideUnderline(
                  child: DropdownButton<int>(
                    value: _selectedYear,
                    isDense: true,
                    items: [DateTime.now().year - 1, DateTime.now().year, DateTime.now().year + 1]
                        .map((y) => DropdownMenuItem(value: y, child: Text('FY $y', style: const TextStyle(fontWeight: FontWeight.bold, color: AppTheme.primary)))).toList(),
                    onChanged: (y) => setState(() => _selectedYear = y!),
                  ),
                ),
              ),
              const SizedBox(width: 12),
              // All months toggle
              GestureDetector(
                onTap: () => setState(() => _showAllMonths = !_showAllMonths),
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
                  decoration: BoxDecoration(
                    color: _showAllMonths ? AppTheme.primary : Colors.grey.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: Text('Full Year', style: TextStyle(fontSize: 12, fontWeight: FontWeight.w600, color: _showAllMonths ? Colors.white : AppTheme.textGrey)),
                ),
              ),
            ],
          ),
          if (!_showAllMonths) ...[
            const SizedBox(height: 8),
            SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: Row(
                children: List.generate(12, (i) {
                  final sel = _selectedMonth == i + 1;
                  return GestureDetector(
                    onTap: () => setState(() => _selectedMonth = i + 1),
                    child: AnimatedContainer(
                      duration: const Duration(milliseconds: 200),
                      margin: const EdgeInsets.only(right: 6),
                      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
                      decoration: BoxDecoration(
                        color: sel ? AppTheme.primary : const Color(0xFFF1F5F9),
                        borderRadius: BorderRadius.circular(20),
                      ),
                      child: Text(months[i], style: TextStyle(fontSize: 12, fontWeight: FontWeight.w600, color: sel ? Colors.white : AppTheme.textGrey)),
                    ),
                  );
                }),
              ),
            ),
          ],
        ],
      ),
    );
  }

  // ── OVERVIEW TAB ─────────────────────────────────────────────────────────────
  Widget _buildOverviewTab() {
    return RefreshIndicator(
      onRefresh: _loadData,
      child: SingleChildScrollView(
        physics: const AlwaysScrollableScrollPhysics(),
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // P&L Summary cards
            Row(
              children: [
                Expanded(child: _bigCard('Total Revenue', _totalRevenue, Icons.trending_up, AppTheme.accent, '₹')),
                const SizedBox(width: 12),
                Expanded(child: _bigCard('Total Expenses', _totalExpenses, Icons.trending_down, AppTheme.danger, '₹')),
              ],
            ),
            const SizedBox(height: 12),
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: _netProfit >= 0 ? [AppTheme.accent, const Color(0xFF059669)] : [AppTheme.danger, const Color(0xFFDC2626)],
                ),
                borderRadius: BorderRadius.circular(12),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text('NET PROFIT / LOSS', style: TextStyle(color: Colors.white70, fontSize: 11, letterSpacing: 1)),
                      const SizedBox(height: 4),
                      Text('₹ ${formatter.format(_netProfit.abs())}',
                          style: const TextStyle(color: Colors.white, fontSize: 24, fontWeight: FontWeight.bold)),
                    ],
                  ),
                  Icon(_netProfit >= 0 ? Icons.arrow_upward_rounded : Icons.arrow_downward_rounded, color: Colors.white, size: 40),
                ],
              ),
            ),

            const SizedBox(height: 20),

            // Quick stats row
            Row(
              children: [
                Expanded(child: _miniCard('Invoices', _filteredInvoices.length.toString(), Icons.receipt, AppTheme.primary)),
                const SizedBox(width: 8),
                Expanded(child: _miniCard('Paid', _filteredInvoices.where((i) => i['status'] == 'paid').length.toString(), Icons.check_circle, AppTheme.accent)),
                const SizedBox(width: 8),
                Expanded(child: _miniCard('Pending', _filteredInvoices.where((i) => i['status'] == 'unpaid').length.toString(), Icons.schedule, AppTheme.warning)),
                const SizedBox(width: 8),
                Expanded(child: _miniCard('Overdue', _filteredInvoices.where((i) => i['status'] == 'overdue').length.toString(), Icons.warning, AppTheme.danger)),
              ],
            ),

            const SizedBox(height: 20),

            // Monthly bar chart (manual Flutter bars — no external chart lib needed)
            const Text('Monthly Revenue vs Expenses', style: TextStyle(fontSize: 15, fontWeight: FontWeight.bold, color: AppTheme.primary)),
            const SizedBox(height: 12),
            _buildBarChart(),

            const SizedBox(height: 20),
            const Text('Business Summary', style: TextStyle(fontSize: 15, fontWeight: FontWeight.bold, color: AppTheme.primary)),
            const SizedBox(height: 12),
            _summaryTable(),
          ],
        ),
      ),
    );
  }

  Widget _buildBarChart() {
    final data = _monthlyData;
    final maxVal = data.fold(0.0, (max, m) => [max, (m['revenue'] as double), (m['expenses'] as double)].reduce((a, b) => a > b ? a : b));
    final months = ['J', 'F', 'M', 'A', 'M', 'J', 'J', 'A', 'S', 'O', 'N', 'D'];
    const barHeight = 120.0;

    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(12), border: Border.all(color: const Color(0xFFE2E8F0))),
      child: Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.end,
            children: [
              _legendDot(AppTheme.accent, 'Revenue'),
              const SizedBox(width: 16),
              _legendDot(AppTheme.danger, 'Expenses'),
            ],
          ),
          const SizedBox(height: 12),
          SizedBox(
            height: barHeight + 30,
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: List.generate(12, (i) {
                final m = data[i];
                final rev = (m['revenue'] as double);
                final exp = (m['expenses'] as double);
                final revH = maxVal > 0 ? (rev / maxVal * barHeight) : 0.0;
                final expH = maxVal > 0 ? (exp / maxVal * barHeight) : 0.0;
                final isCurrentMonth = !_showAllMonths && i + 1 == _selectedMonth;

                return Expanded(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        crossAxisAlignment: CrossAxisAlignment.end,
                        children: [
                          Container(width: 7, height: revH.clamp(2, barHeight), decoration: BoxDecoration(color: AppTheme.accent.withOpacity(isCurrentMonth ? 1 : 0.7), borderRadius: const BorderRadius.vertical(top: Radius.circular(3)))),
                          const SizedBox(width: 2),
                          Container(width: 7, height: expH.clamp(2, barHeight), decoration: BoxDecoration(color: AppTheme.danger.withOpacity(isCurrentMonth ? 1 : 0.6), borderRadius: const BorderRadius.vertical(top: Radius.circular(3)))),
                        ],
                      ),
                      const SizedBox(height: 4),
                      Text(months[i], style: TextStyle(fontSize: 10, fontWeight: isCurrentMonth ? FontWeight.bold : FontWeight.normal, color: isCurrentMonth ? AppTheme.primary : AppTheme.textGrey)),
                    ],
                  ),
                );
              }),
            ),
          ),
        ],
      ),
    );
  }

  Widget _legendDot(Color color, String label) => Row(children: [
    Container(width: 10, height: 10, decoration: BoxDecoration(color: color, borderRadius: BorderRadius.circular(3))),
    const SizedBox(width: 4),
    Text(label, style: const TextStyle(fontSize: 11, color: AppTheme.textGrey)),
  ]);

  Widget _summaryTable() {
    return Container(
      decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(12), border: Border.all(color: const Color(0xFFE2E8F0))),
      child: Column(
        children: [
          _tableRow('Total Invoiced', '₹ ${formatter.format(_totalInvoiced)}', AppTheme.primary, first: true),
          _tableRow('Amount Received', '₹ ${formatter.format(_totalRevenue)}', AppTheme.accent),
          _tableRow('Amount Pending', '₹ ${formatter.format(_totalPending)}', AppTheme.warning),
          _tableRow('Total Expenses', '₹ ${formatter.format(_totalExpenses)}', AppTheme.danger),
          _tableRow('Net Profit', '₹ ${formatter.format(_netProfit)}', _netProfit >= 0 ? AppTheme.accent : AppTheme.danger, last: true, bold: true),
        ],
      ),
    );
  }

  Widget _tableRow(String label, String value, Color color, {bool first = false, bool last = false, bool bold = false}) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      decoration: BoxDecoration(
        border: Border(
          bottom: last ? BorderSide.none : const BorderSide(color: Color(0xFFF1F5F9)),
          top: first ? BorderSide.none : BorderSide.none,
        ),
        color: bold ? color.withOpacity(0.05) : Colors.white,
        borderRadius: BorderRadius.only(
          topLeft: first ? const Radius.circular(12) : Radius.zero,
          topRight: first ? const Radius.circular(12) : Radius.zero,
          bottomLeft: last ? const Radius.circular(12) : Radius.zero,
          bottomRight: last ? const Radius.circular(12) : Radius.zero,
        ),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Row(children: [
            Container(width: 4, height: 16, decoration: BoxDecoration(color: color, borderRadius: BorderRadius.circular(2))),
            const SizedBox(width: 10),
            Text(label, style: TextStyle(fontWeight: bold ? FontWeight.bold : FontWeight.normal, fontSize: bold ? 15 : 14, color: AppTheme.textDark)),
          ]),
          Text(value, style: TextStyle(fontWeight: bold ? FontWeight.bold : FontWeight.w600, fontSize: bold ? 15 : 14, color: color)),
        ],
      ),
    );
  }

  // ── SALES TAB ────────────────────────────────────────────────────────────────
  Widget _buildSalesTab() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Revenue cards
          Row(
            children: [
              Expanded(child: _bigCard('Collected', _totalRevenue, Icons.check_circle, AppTheme.accent, '₹')),
              const SizedBox(width: 12),
              Expanded(child: _bigCard('Pending', _totalPending, Icons.schedule, AppTheme.warning, '₹')),
            ],
          ),

          const SizedBox(height: 20),
          const Text('Invoice Breakdown', style: TextStyle(fontSize: 15, fontWeight: FontWeight.bold, color: AppTheme.primary)),
          const SizedBox(height: 12),

          // Status breakdown
          ...[
            ('paid', AppTheme.accent, Icons.check_circle, 'Paid Invoices'),
            ('unpaid', AppTheme.warning, Icons.schedule, 'Unpaid Invoices'),
            ('overdue', AppTheme.danger, Icons.warning, 'Overdue Invoices'),
            ('cancelled', Colors.grey, Icons.cancel, 'Cancelled'),
          ].map((item) {
            final inv = _filteredInvoices.where((i) => i['status'] == item.$1).toList();
            final total = inv.fold(0.0, (s, i) => s + (i['total'] as num).toDouble());
            return Container(
              margin: const EdgeInsets.only(bottom: 10),
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(12), border: Border.all(color: const Color(0xFFE2E8F0))),
              child: Row(
                children: [
                  Container(width: 42, height: 42, decoration: BoxDecoration(color: item.$2.withOpacity(0.1), borderRadius: BorderRadius.circular(10)),
                      child: Icon(item.$3, color: item.$2, size: 22)),
                  const SizedBox(width: 12),
                  Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text(item.$4, style: const TextStyle(fontWeight: FontWeight.w600)),
                    Text('${inv.length} invoice${inv.length != 1 ? 's' : ''}', style: const TextStyle(color: AppTheme.textGrey, fontSize: 12)),
                  ])),
                  Text('₹ ${formatter.format(total)}', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15, color: item.$2)),
                ],
              ),
            );
          }),

          const SizedBox(height: 20),
          const Text('Recent Invoices', style: TextStyle(fontSize: 15, fontWeight: FontWeight.bold, color: AppTheme.primary)),
          const SizedBox(height: 12),
          if (_filteredInvoices.isEmpty)
            _emptyState('No invoices in this period', Icons.receipt_long_outlined)
          else
            ..._filteredInvoices.take(10).map((inv) {
              final color = {'paid': AppTheme.accent, 'unpaid': AppTheme.warning, 'overdue': AppTheme.danger, 'cancelled': Colors.grey}[inv['status']] ?? Colors.grey;
              return Container(
                margin: const EdgeInsets.only(bottom: 8),
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(10), border: Border.all(color: const Color(0xFFE2E8F0))),
                child: Row(
                  children: [
                    Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Text(inv['invoiceNumber'] ?? '', style: const TextStyle(fontWeight: FontWeight.bold, color: AppTheme.primary, fontSize: 13)),
                      Text(inv['clientName'] ?? '', style: const TextStyle(color: AppTheme.textGrey, fontSize: 12)),
                    ])),
                    Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
                      Text('₹ ${formatter.format((inv['total'] as num).toDouble())}', style: const TextStyle(fontWeight: FontWeight.bold)),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                        decoration: BoxDecoration(color: color.withOpacity(0.1), borderRadius: BorderRadius.circular(10)),
                        child: Text((inv['status'] ?? '').toUpperCase(), style: TextStyle(fontSize: 10, color: color, fontWeight: FontWeight.bold)),
                      ),
                    ]),
                  ],
                ),
              );
            }),
        ],
      ),
    );
  }

  // ── EXPENSES TAB ─────────────────────────────────────────────────────────────
  Widget _buildExpensesTab() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _bigCard('Total Expenses', _totalExpenses, Icons.money_off, AppTheme.danger, '₹', fullWidth: true),

          const SizedBox(height: 20),
          const Text('By Category', style: TextStyle(fontSize: 15, fontWeight: FontWeight.bold, color: AppTheme.primary)),
          const SizedBox(height: 12),

          if (_expenseByCategory.isEmpty)
            _emptyState('No expenses in this period', Icons.money_off_outlined)
          else ...[
            // Category breakdown with visual bars
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(12), border: Border.all(color: const Color(0xFFE2E8F0))),
              child: Column(
                children: _expenseByCategory.entries.map((entry) {
                  final pct = _totalExpenses > 0 ? entry.value / _totalExpenses : 0.0;
                  final colors = [AppTheme.danger, AppTheme.warning, AppTheme.primary, AppTheme.secondary, AppTheme.accent, Colors.purple, Colors.teal];
                  final colorIndex = _expenseByCategory.keys.toList().indexOf(entry.key) % colors.length;
                  final color = colors[colorIndex];
                  return Padding(
                    padding: const EdgeInsets.only(bottom: 14),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
                          Row(children: [
                            Text(Expense.categoryIcons[entry.key] ?? '📦', style: const TextStyle(fontSize: 16)),
                            const SizedBox(width: 8),
                            Text(entry.key, style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 13)),
                          ]),
                          Text('₹ ${formatter.format(entry.value)}', style: TextStyle(fontWeight: FontWeight.bold, color: color)),
                        ]),
                        const SizedBox(height: 6),
                        Row(children: [
                          Expanded(
                            child: ClipRRect(
                              borderRadius: BorderRadius.circular(4),
                              child: LinearProgressIndicator(value: pct, backgroundColor: color.withOpacity(0.1), valueColor: AlwaysStoppedAnimation<Color>(color), minHeight: 6),
                            ),
                          ),
                          const SizedBox(width: 8),
                          Text('${(pct * 100).toStringAsFixed(1)}%', style: const TextStyle(fontSize: 11, color: AppTheme.textGrey)),
                        ]),
                      ],
                    ),
                  );
                }).toList(),
              ),
            ),

            const SizedBox(height: 20),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text('All Expenses', style: TextStyle(fontSize: 15, fontWeight: FontWeight.bold, color: AppTheme.primary)),
                TextButton.icon(
                  icon: const Icon(Icons.add, size: 16),
                  label: const Text('Add'),
                  onPressed: () async {
                    await Navigator.push(context, MaterialPageRoute(builder: (_) => const AddExpenseScreen()));
                    _loadData();
                  },
                ),
              ],
            ),
            const SizedBox(height: 8),
            ..._filteredExpenses.map((e) {
              final expense = Expense.fromMap(e);
              return Card(
                margin: const EdgeInsets.only(bottom: 8),
                child: ListTile(
                  leading: Container(
                    width: 42, height: 42,
                    decoration: BoxDecoration(color: AppTheme.danger.withOpacity(0.1), borderRadius: BorderRadius.circular(10)),
                    child: Center(child: Text(Expense.categoryIcons[expense.category] ?? '📦', style: const TextStyle(fontSize: 20))),
                  ),
                  title: Text(expense.title, style: const TextStyle(fontWeight: FontWeight.w600)),
                  subtitle: Text('${expense.category} · ${DateFormat('dd MMM yyyy').format(expense.date)}', style: const TextStyle(fontSize: 12)),
                  trailing: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: [
                      Text('₹ ${formatter.format(expense.amount)}', style: const TextStyle(fontWeight: FontWeight.bold, color: AppTheme.danger, fontSize: 14)),
                      GestureDetector(
                        onTap: () async {
                          await DatabaseService.instance.deleteExpense(expense.id!);
                          _loadData();
                        },
                        child: const Text('Delete', style: TextStyle(color: Colors.grey, fontSize: 10)),
                      ),
                    ],
                  ),
                  onTap: () async {
                    await Navigator.push(context, MaterialPageRoute(builder: (_) => AddExpenseScreen(expense: expense)));
                    _loadData();
                  },
                ),
              );
            }),
          ],
        ],
      ),
    );
  }

  // ── Reusable widgets ─────────────────────────────────────────────────────────
  Widget _bigCard(String label, double amount, IconData icon, Color color, String prefix, {bool fullWidth = false}) {
    return Container(
      width: fullWidth ? double.infinity : null,
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: color.withOpacity(0.08),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: color.withOpacity(0.3)),
      ),
      child: Row(
        children: [
          Container(padding: const EdgeInsets.all(10), decoration: BoxDecoration(color: color.withOpacity(0.15), borderRadius: BorderRadius.circular(10)),
              child: Icon(icon, color: color, size: 24)),
          const SizedBox(width: 12),
          Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(label, style: const TextStyle(color: AppTheme.textGrey, fontSize: 12)),
            Text('$prefix ${formatter.format(amount)}', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18, color: color)),
          ]),
        ],
      ),
    );
  }

  Widget _miniCard(String label, String value, IconData icon, Color color) {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 8),
      decoration: BoxDecoration(color: color.withOpacity(0.08), borderRadius: BorderRadius.circular(10), border: Border.all(color: color.withOpacity(0.2))),
      child: Column(children: [
        Icon(icon, color: color, size: 20),
        const SizedBox(height: 4),
        Text(value, style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18, color: color)),
        Text(label, style: const TextStyle(fontSize: 9, color: AppTheme.textGrey), textAlign: TextAlign.center),
      ]),
    );
  }

  Widget _emptyState(String msg, IconData icon) => Padding(
    padding: const EdgeInsets.symmetric(vertical: 40),
    child: Center(child: Column(children: [
      Icon(icon, size: 60, color: Colors.grey[300]),
      const SizedBox(height: 12),
      Text(msg, style: const TextStyle(color: AppTheme.textGrey)),
    ])),
  );
}
