import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../../models/quotation.dart';
import '../../services/database_service.dart';
import '../../utils/app_theme.dart';
import 'create_quotation_screen.dart';
import 'quotation_detail_screen.dart';

class QuotationsScreen extends StatefulWidget {
  const QuotationsScreen({super.key});

  @override
  State<QuotationsScreen> createState() => _QuotationsScreenState();
}

class _QuotationsScreenState extends State<QuotationsScreen> {
  List<Map<String, dynamic>> _quotations = [];
  bool _isLoading = true;
  String _filterStatus = 'all';

  final _statusColors = {
    'draft': Colors.grey,
    'sent': Colors.blue,
    'accepted': AppTheme.accent,
    'rejected': AppTheme.danger,
  };

  @override
  void initState() {
    super.initState();
    _loadQuotations();
  }

  Future<void> _loadQuotations() async {
    setState(() => _isLoading = true);
    final data = await DatabaseService.instance.getAllQuotations();
    setState(() {
      _quotations = data;
      _isLoading = false;
    });
  }

  List<Map<String, dynamic>> get _filteredQuotations {
    if (_filterStatus == 'all') return _quotations;
    return _quotations.where((q) => q['status'] == _filterStatus).toList();
  }

  @override
  Widget build(BuildContext context) {
    final formatter = NumberFormat('#,##,##0.00', 'en_IN');

    return Scaffold(
      appBar: AppBar(
        title: const Text('Quotations'),
        actions: [
          IconButton(
            icon: const Icon(Icons.add),
            onPressed: () async {
              await Navigator.push(context, MaterialPageRoute(builder: (_) => const CreateQuotationScreen()));
              _loadQuotations();
            },
          ),
        ],
      ),
      body: Column(
        children: [
          // Filter chips
          Container(
            color: AppTheme.primary,
            padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
            child: SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: Row(
                children: ['all', 'draft', 'sent', 'accepted', 'rejected'].map((status) {
                  final isSelected = _filterStatus == status;
                  return Padding(
                    padding: const EdgeInsets.only(right: 8),
                    child: FilterChip(
                      label: Text(status.toUpperCase()),
                      selected: isSelected,
                      onSelected: (_) => setState(() => _filterStatus = status),
                      selectedColor: Colors.white,
                      backgroundColor: Colors.white.withOpacity(0.2),
                      labelStyle: TextStyle(
                        color: isSelected ? AppTheme.primary : Colors.white,
                        fontWeight: FontWeight.w600,
                        fontSize: 11,
                      ),
                      checkmarkColor: AppTheme.primary,
                    ),
                  );
                }).toList(),
              ),
            ),
          ),

          // Count
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
            child: Row(
              children: [
                Text('${_filteredQuotations.length} Quotations', style: const TextStyle(color: AppTheme.textGrey, fontWeight: FontWeight.w500)),
              ],
            ),
          ),

          // List
          Expanded(
            child: _isLoading
                ? const Center(child: CircularProgressIndicator())
                : _filteredQuotations.isEmpty
                    ? _buildEmptyState()
                    : RefreshIndicator(
                        onRefresh: _loadQuotations,
                        child: ListView.builder(
                          padding: const EdgeInsets.symmetric(horizontal: 16),
                          itemCount: _filteredQuotations.length,
                          itemBuilder: (context, index) {
                            final q = _filteredQuotations[index];
                            final status = q['status'] ?? 'draft';
                            final statusColor = _statusColors[status] ?? Colors.grey;
                            final date = DateTime.parse(q['date']);
                            final validUntil = DateTime.parse(q['validUntil']);
                            final isExpired = validUntil.isBefore(DateTime.now()) && status == 'sent';

                            return Card(
                              margin: const EdgeInsets.only(bottom: 12),
                              child: InkWell(
                                borderRadius: BorderRadius.circular(12),
                                onTap: () async {
                                  final quotation = Quotation.fromMap(q);
                                  await Navigator.push(context, MaterialPageRoute(
                                    builder: (_) => QuotationDetailScreen(quotation: quotation),
                                  ));
                                  _loadQuotations();
                                },
                                child: Padding(
                                  padding: const EdgeInsets.all(16),
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Row(
                                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                        children: [
                                          Text(q['quotationNumber'] ?? '',
                                              style: const TextStyle(fontWeight: FontWeight.bold, color: AppTheme.primary, fontSize: 15)),
                                          Row(
                                            children: [
                                              if (isExpired)
                                                Container(
                                                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                                                  margin: const EdgeInsets.only(right: 6),
                                                  decoration: BoxDecoration(
                                                    color: AppTheme.danger.withOpacity(0.1),
                                                    borderRadius: BorderRadius.circular(20),
                                                  ),
                                                  child: const Text('EXPIRED', style: TextStyle(fontSize: 9, color: AppTheme.danger, fontWeight: FontWeight.bold)),
                                                ),
                                              Container(
                                                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                                                decoration: BoxDecoration(
                                                  color: statusColor.withOpacity(0.1),
                                                  borderRadius: BorderRadius.circular(20),
                                                ),
                                                child: Text(status.toUpperCase(),
                                                    style: TextStyle(fontSize: 10, color: statusColor, fontWeight: FontWeight.bold)),
                                              ),
                                            ],
                                          ),
                                        ],
                                      ),
                                      const SizedBox(height: 8),
                                      Row(
                                        children: [
                                          const Icon(Icons.person, size: 14, color: AppTheme.textGrey),
                                          const SizedBox(width: 4),
                                          Text(
                                            q['clientCompany'] != null && (q['clientCompany'] as String).isNotEmpty
                                                ? '${q['clientName']} (${q['clientCompany']})'
                                                : q['clientName'] ?? '',
                                            style: const TextStyle(color: AppTheme.textGrey, fontSize: 13),
                                          ),
                                        ],
                                      ),
                                      const SizedBox(height: 6),
                                      Row(
                                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                        children: [
                                          Row(
                                            children: [
                                              const Icon(Icons.calendar_today, size: 13, color: AppTheme.textGrey),
                                              const SizedBox(width: 4),
                                              Text(DateFormat('dd MMM yyyy').format(date),
                                                  style: const TextStyle(color: AppTheme.textGrey, fontSize: 12)),
                                            ],
                                          ),
                                          Text(
                                            '₹ ${formatter.format((q['total'] as num).toDouble())}',
                                            style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: AppTheme.textDark),
                                          ),
                                        ],
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            );
                          },
                        ),
                      ),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () async {
          await Navigator.push(context, MaterialPageRoute(builder: (_) => const CreateQuotationScreen()));
          _loadQuotations();
        },
        backgroundColor: AppTheme.primary,
        child: const Icon(Icons.add, color: Colors.white),
      ),
    );
  }

  Widget _buildEmptyState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(Icons.description_outlined, size: 80, color: Colors.grey[300]),
          const SizedBox(height: 16),
          const Text('No quotations yet', style: TextStyle(fontSize: 18, color: AppTheme.textGrey)),
          const SizedBox(height: 8),
          const Text('Tap + to create your first quotation', style: TextStyle(color: AppTheme.textGrey)),
        ],
      ),
    );
  }
}
