import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../../models/quotation.dart';
import '../../services/database_service.dart';
import '../../services/quotation_service.dart';
import '../../utils/app_theme.dart';

class QuotationDetailScreen extends StatefulWidget {
  final Quotation quotation;
  const QuotationDetailScreen({super.key, required this.quotation});

  @override
  State<QuotationDetailScreen> createState() => _QuotationDetailScreenState();
}

class _QuotationDetailScreenState extends State<QuotationDetailScreen> {
  late Quotation _quotation;
  bool _isGeneratingPDF = false;
  final formatter = NumberFormat('#,##,##0.00', 'en_IN');
  final dateFormatter = DateFormat('dd MMM yyyy');

  // Company info - user should update these
  final Map<String, String> _companyInfo = {
    'name': 'TECH SPWORLD',
    'tagline': 'BEING SECURE',
    'address': 'Ahmedabad, Gujarat, India',
    'city': 'Ahmedabad',
    'state': 'Gujarat',
    'pincode': '380001',
    'gstin': 'Update Your GSTIN',
    'phone': 'Update Your Phone',
    'email': 'info@techspworld.com',
  };

  final _statusColors = {
    'draft': Colors.grey,
    'sent': Colors.blue,
    'accepted': AppTheme.accent,
    'rejected': AppTheme.danger,
  };

  @override
  void initState() {
    super.initState();
    _quotation = widget.quotation;
  }

  Future<void> _updateStatus(String newStatus) async {
    final updated = _quotation.toMap();
    updated['status'] = newStatus;
    await DatabaseService.instance.updateQuotation(updated);
    setState(() => _quotation = Quotation.fromMap(updated));
  }

  Future<void> _generatePDF() async {
    setState(() => _isGeneratingPDF = true);
    try {
      await QuotationService.instance.generateAndSharePDF(_quotation, _companyInfo);
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error generating PDF: $e'), backgroundColor: AppTheme.danger),
        );
      }
    }
    setState(() => _isGeneratingPDF = false);
  }

  Future<void> _delete() async {
    final confirm = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Delete Quotation'),
        content: const Text('Are you sure? This cannot be undone.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancel')),
          TextButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Delete', style: TextStyle(color: AppTheme.danger))),
        ],
      ),
    );
    if (confirm == true) {
      await DatabaseService.instance.deleteQuotation(_quotation.id!);
      if (mounted) Navigator.pop(context);
    }
  }

  @override
  Widget build(BuildContext context) {
    final status = _quotation.status;
    final statusColor = _statusColors[status] ?? Colors.grey;

    return Scaffold(
      appBar: AppBar(
        title: Text(_quotation.quotationNumber),
        actions: [
          IconButton(icon: const Icon(Icons.delete), onPressed: _delete),
        ],
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            // Header banner
            Container(
              color: AppTheme.primary,
              width: double.infinity,
              padding: const EdgeInsets.all(20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(_quotation.clientName, style: const TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold)),
                          if (_quotation.clientCompany != null)
                            Text(_quotation.clientCompany!, style: TextStyle(color: Colors.white.withOpacity(0.8))),
                        ],
                      ),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
                        decoration: BoxDecoration(
                          color: statusColor.withOpacity(0.2),
                          borderRadius: BorderRadius.circular(20),
                          border: Border.all(color: statusColor),
                        ),
                        child: Text(status.toUpperCase(), style: TextStyle(color: statusColor, fontWeight: FontWeight.bold, fontSize: 12)),
                      ),
                    ],
                  ),
                  const SizedBox(height: 16),
                  Row(
                    children: [
                      _headerInfo('Date', dateFormatter.format(_quotation.date)),
                      const SizedBox(width: 24),
                      _headerInfo('Valid Until', dateFormatter.format(_quotation.validUntil)),
                      const SizedBox(width: 24),
                      _headerInfo('GST', _quotation.isInterState ? 'IGST' : 'CGST+SGST'),
                    ],
                  ),
                ],
              ),
            ),

            Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Total amount card
                  Container(
                    width: double.infinity,
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      gradient: LinearGradient(colors: [AppTheme.primary, AppTheme.secondary]),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Column(
                      children: [
                        const Text('Total Amount', style: TextStyle(color: Colors.white70, fontSize: 12)),
                        const SizedBox(height: 4),
                        Text('₹ ${formatter.format(_quotation.total)}',
                            style: const TextStyle(color: Colors.white, fontSize: 28, fontWeight: FontWeight.bold)),
                        Text(QuotationService.instance.numberToWords(_quotation.total),
                            style: TextStyle(color: Colors.white.withOpacity(0.8), fontSize: 11), textAlign: TextAlign.center),
                      ],
                    ),
                  ),

                  const SizedBox(height: 16),

                  // Action Buttons
                  Row(
                    children: [
                      Expanded(
                        child: ElevatedButton.icon(
                          icon: _isGeneratingPDF
                              ? const SizedBox(height: 16, width: 16, child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2))
                              : const Icon(Icons.picture_as_pdf, size: 18),
                          label: const Text('Download PDF'),
                          onPressed: _isGeneratingPDF ? null : _generatePDF,
                        ),
                      ),
                    ],
                  ),

                  const SizedBox(height: 12),

                  // Status actions
                  if (status == 'draft')
                    Row(
                      children: [
                        Expanded(child: OutlinedButton(onPressed: () => _updateStatus('sent'), child: const Text('Mark as Sent'))),
                      ],
                    ),
                  if (status == 'sent')
                    Row(
                      children: [
                        Expanded(
                          child: ElevatedButton(
                            onPressed: () => _updateStatus('accepted'),
                            style: ElevatedButton.styleFrom(backgroundColor: AppTheme.accent),
                            child: const Text('Mark Accepted'),
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: ElevatedButton(
                            onPressed: () => _updateStatus('rejected'),
                            style: ElevatedButton.styleFrom(backgroundColor: AppTheme.danger),
                            child: const Text('Mark Rejected'),
                          ),
                        ),
                      ],
                    ),

                  const SizedBox(height: 20),

                  // Items table
                  const Text('Items', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: AppTheme.primary)),
                  const SizedBox(height: 10),

                  Container(
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(color: const Color(0xFFE2E8F0)),
                    ),
                    child: Column(
                      children: [
                        // Table header
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                          decoration: const BoxDecoration(
                            color: AppTheme.primary,
                            borderRadius: BorderRadius.only(topLeft: Radius.circular(12), topRight: Radius.circular(12)),
                          ),
                          child: const Row(
                            children: [
                              Expanded(flex: 3, child: Text('Item', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 12))),
                              Expanded(child: Text('Qty', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 12), textAlign: TextAlign.center)),
                              Expanded(child: Text('Rate', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 12), textAlign: TextAlign.right)),
                              Expanded(child: Text('Total', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 12), textAlign: TextAlign.right)),
                            ],
                          ),
                        ),
                        ...(_quotation.items.asMap().entries.map((entry) {
                          final i = entry.key;
                          final item = entry.value;
                          return Container(
                            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                            color: i % 2 == 0 ? Colors.white : const Color(0xFFF8FAFC),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Row(
                                  children: [
                                    Expanded(
                                      flex: 3,
                                      child: Column(
                                        crossAxisAlignment: CrossAxisAlignment.start,
                                        children: [
                                          Text(item.description, style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 13)),
                                          if (item.hsnCode != null) Text('HSN: ${item.hsnCode}', style: const TextStyle(fontSize: 10, color: AppTheme.textGrey)),
                                          Text('GST: ${item.gstRate}%', style: const TextStyle(fontSize: 10, color: AppTheme.secondary)),
                                        ],
                                      ),
                                    ),
                                    Expanded(child: Text('${item.quantity} ${item.unit}', textAlign: TextAlign.center, style: const TextStyle(fontSize: 12))),
                                    Expanded(child: Text('₹ ${formatter.format(item.rate)}', textAlign: TextAlign.right, style: const TextStyle(fontSize: 12))),
                                    Expanded(child: Text('₹ ${formatter.format(item.totalAmount)}', textAlign: TextAlign.right, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13))),
                                  ],
                                ),
                              ],
                            ),
                          );
                        })),
                      ],
                    ),
                  ),

                  const SizedBox(height: 16),

                  // GST Summary
                  Container(
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(color: const Color(0xFFE2E8F0)),
                    ),
                    child: Column(
                      children: [
                        _totalRow('Subtotal', '₹ ${formatter.format(_quotation.subtotal)}'),
                        if (!_quotation.isInterState) ...[
                          _totalRow('CGST', '₹ ${formatter.format(_quotation.cgst)}'),
                          _totalRow('SGST', '₹ ${formatter.format(_quotation.sgst)}'),
                        ] else
                          _totalRow('IGST', '₹ ${formatter.format(_quotation.igst)}'),
                        const Divider(),
                        _totalRow('TOTAL', '₹ ${formatter.format(_quotation.total)}', isTotal: true),
                      ],
                    ),
                  ),

                  if (_quotation.notes != null) ...[
                    const SizedBox(height: 16),
                    Container(
                      width: double.infinity,
                      padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(
                        color: const Color(0xFFFFFBEB),
                        borderRadius: BorderRadius.circular(10),
                        border: Border.all(color: const Color(0xFFFDE68A)),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Text('Notes', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 13)),
                          const SizedBox(height: 4),
                          Text(_quotation.notes!, style: const TextStyle(fontSize: 13)),
                        ],
                      ),
                    ),
                  ],
                  const SizedBox(height: 20),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _headerInfo(String label, String value) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(label, style: TextStyle(color: Colors.white.withOpacity(0.7), fontSize: 10)),
        Text(value, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w600, fontSize: 12)),
      ],
    );
  }

  Widget _totalRow(String label, String value, {bool isTotal = false}) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(label, style: TextStyle(fontWeight: isTotal ? FontWeight.bold : FontWeight.normal, color: isTotal ? AppTheme.primary : AppTheme.textDark, fontSize: isTotal ? 16 : 14)),
          Text(value, style: TextStyle(fontWeight: isTotal ? FontWeight.bold : FontWeight.normal, color: isTotal ? AppTheme.primary : AppTheme.textDark, fontSize: isTotal ? 16 : 14)),
        ],
      ),
    );
  }
}
