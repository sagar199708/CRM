import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:uuid/uuid.dart';
import '../../models/client.dart';
import '../../models/invoice.dart';
import '../../services/database_service.dart';
import '../../utils/app_theme.dart';

class CreateInvoiceScreen extends StatefulWidget {
  const CreateInvoiceScreen({super.key});

  @override
  State<CreateInvoiceScreen> createState() => _CreateInvoiceScreenState();
}

class _CreateInvoiceScreenState extends State<CreateInvoiceScreen> {
  Client? _selectedClient;
  List<Client> _clients = [];
  DateTime _date = DateTime.now();
  DateTime _dueDate = DateTime.now().add(const Duration(days: 15));

  bool _applyGST = true;
  bool _isInterState = false;

  final _notesController = TextEditingController();
  List<_ItemRow> _items = [];
  bool _isSaving = false;

  final formatter = NumberFormat('#,##,##0.00', 'en_IN');

  double get _subtotal => _items.fold(0, (s, i) => s + i.amount);
  double get _totalGst => _applyGST ? _items.fold(0, (s, i) => s + i.gstAmount) : 0;
  double get _cgst => (_applyGST && !_isInterState) ? _totalGst / 2 : 0;
  double get _sgst => (_applyGST && !_isInterState) ? _totalGst / 2 : 0;
  double get _igst => (_applyGST && _isInterState) ? _totalGst : 0;
  double get _total => _subtotal + _totalGst;

  String _generateInvoiceNumber(int count) {
    final now = DateTime.now();
    final year = now.year.toString().substring(2);
    final month = now.month.toString().padLeft(2, '0');
    return 'INV-$year$month-${(count + 1).toString().padLeft(3, '0')}';
  }

  @override
  void initState() {
    super.initState();
    _loadClients();
    _items.add(_ItemRow());
  }

  Future<void> _loadClients() async {
    final clients = await DatabaseService.instance.getAllClients();
    setState(() => _clients = clients);
  }

  Future<void> _save() async {
    if (_selectedClient == null) { _showError('Please select a client'); return; }
    if (_items.every((i) => i.descriptionController.text.trim().isEmpty)) {
      _showError('Please add at least one item'); return;
    }
    setState(() => _isSaving = true);

    final invoices = await DatabaseService.instance.getAllInvoices();
    final invoiceNumber = _generateInvoiceNumber(invoices.length);

    final items = _items
        .where((i) => i.descriptionController.text.trim().isNotEmpty)
        .map((i) => InvoiceItem(
              description: i.descriptionController.text.trim(),
              hsnCode: i.hsnController.text.trim().isEmpty ? null : i.hsnController.text.trim(),
              quantity: double.tryParse(i.qtyController.text) ?? 1,
              unit: i.unit,
              rate: double.tryParse(i.rateController.text) ?? 0,
              gstRate: _applyGST ? i.gstRate : 0,
            ))
        .toList();

    final invoice = Invoice(
      id: const Uuid().v4(),
      clientId: _selectedClient!.id!,
      clientName: _selectedClient!.name,
      clientCompany: _selectedClient!.companyName,
      invoiceNumber: invoiceNumber,
      date: _date,
      dueDate: _dueDate,
      items: items,
      subtotal: _subtotal,
      cgst: _cgst,
      sgst: _sgst,
      igst: _igst,
      total: _total,
      notes: _notesController.text.trim().isEmpty ? null : _notesController.text.trim(),
      status: 'unpaid',
      isInterState: _isInterState,
      applyGST: _applyGST,
    );

    await DatabaseService.instance.createInvoice(invoice.toMap());
    if (mounted) {
      Navigator.pop(context);
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Invoice created!'), backgroundColor: AppTheme.accent),
      );
    }
  }

  void _showError(String msg) =>
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(msg), backgroundColor: AppTheme.danger));

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Create Invoice'),
        actions: [
          TextButton(
            onPressed: _isSaving ? null : _save,
            child: _isSaving
                ? const SizedBox(height: 16, width: 16, child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2))
                : const Text('SAVE', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
          ),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _sectionTitle('Client'),
            const SizedBox(height: 10),
            DropdownButtonFormField<Client>(
              value: _selectedClient,
              hint: const Text('Select Client'),
              decoration: const InputDecoration(prefixIcon: Icon(Icons.person, color: AppTheme.primary, size: 20)),
              items: _clients.map((c) => DropdownMenuItem(
                value: c,
                child: Text(c.companyName != null ? '${c.name} (${c.companyName})' : c.name),
              )).toList(),
              onChanged: (c) => setState(() => _selectedClient = c),
            ),

            const SizedBox(height: 20),
            _sectionTitle('Dates'),
            const SizedBox(height: 10),
            Row(
              children: [
                Expanded(child: _datePicker('Invoice Date', _date, (d) => setState(() => _date = d))),
                const SizedBox(width: 12),
                Expanded(child: _datePicker('Due Date', _dueDate, (d) => setState(() => _dueDate = d))),
              ],
            ),

            const SizedBox(height: 20),
            _sectionTitle('GST Settings'),
            const SizedBox(height: 10),
            _buildGSTToggleCard(),

            const SizedBox(height: 20),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                _sectionTitle('Items'),
                TextButton.icon(
                  icon: const Icon(Icons.add, size: 18),
                  label: const Text('Add Item'),
                  onPressed: () => setState(() => _items.add(_ItemRow())),
                ),
              ],
            ),
            const SizedBox(height: 10),
            ..._items.asMap().entries.map((e) => _buildItemCard(e.value, e.key)),

            const SizedBox(height: 20),
            if (_subtotal > 0) _buildSummaryCard(),

            const SizedBox(height: 20),
            _sectionTitle('Notes (Optional)'),
            const SizedBox(height: 10),
            TextFormField(
              controller: _notesController,
              maxLines: 3,
              decoration: const InputDecoration(
                hintText: 'Payment instructions, bank details, etc.',
                prefixIcon: Icon(Icons.note, color: AppTheme.primary, size: 20),
              ),
            ),

            const SizedBox(height: 30),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: _isSaving ? null : _save,
                child: _isSaving
                    ? const SizedBox(height: 20, width: 20, child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2))
                    : const Text('Create Invoice', style: TextStyle(fontSize: 16)),
              ),
            ),
            const SizedBox(height: 20),
          ],
        ),
      ),
    );
  }

  Widget _buildGSTToggleCard() {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: _applyGST ? AppTheme.accent : const Color(0xFFE2E8F0), width: _applyGST ? 1.5 : 1),
        boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.04), blurRadius: 8)],
      ),
      child: Column(
        children: [
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
            child: Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: (_applyGST ? AppTheme.accent : Colors.grey).withOpacity(0.1),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Icon(Icons.receipt_long, color: _applyGST ? AppTheme.accent : Colors.grey, size: 22),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        _applyGST ? 'GST Applied ✓' : 'No GST / Bill without Tax',
                        style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15,
                            color: _applyGST ? AppTheme.accent : Colors.grey[700]),
                      ),
                      Text(
                        _applyGST ? 'Tax will be calculated on items' : 'Simple bill — no tax added',
                        style: const TextStyle(fontSize: 11, color: AppTheme.textGrey),
                      ),
                    ],
                  ),
                ),
                Switch(
                  value: _applyGST,
                  onChanged: (v) => setState(() => _applyGST = v),
                  activeColor: AppTheme.accent,
                ),
              ],
            ),
          ),
          if (_applyGST) ...[
            const Divider(height: 1),
            RadioListTile<bool>(
              value: false,
              groupValue: _isInterState,
              onChanged: (v) => setState(() => _isInterState = false),
              title: const Text('Intra-State — CGST + SGST', style: TextStyle(fontSize: 13, fontWeight: FontWeight.w600)),
              subtitle: const Text('Same state as your company (Gujarat)', style: TextStyle(fontSize: 11)),
              activeColor: AppTheme.accent,
              dense: true,
            ),
            RadioListTile<bool>(
              value: true,
              groupValue: _isInterState,
              onChanged: (v) => setState(() => _isInterState = true),
              title: const Text('Inter-State — IGST', style: TextStyle(fontSize: 13, fontWeight: FontWeight.w600)),
              subtitle: const Text('Client in a different state', style: TextStyle(fontSize: 11)),
              activeColor: AppTheme.accent,
              dense: true,
            ),
          ],
        ],
      ),
    );
  }

  Widget _buildItemCard(_ItemRow item, int index) {
    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text('Item ${index + 1}', style: const TextStyle(fontWeight: FontWeight.bold, color: AppTheme.accent)),
                if (_items.length > 1)
                  IconButton(
                    icon: const Icon(Icons.delete_outline, color: AppTheme.danger, size: 20),
                    onPressed: () => setState(() => _items.removeAt(index)),
                    padding: EdgeInsets.zero, constraints: const BoxConstraints(),
                  ),
              ],
            ),
            const SizedBox(height: 8),
            TextFormField(
              controller: item.descriptionController,
              decoration: const InputDecoration(labelText: 'Description *', isDense: true),
              onChanged: (_) => setState(() {}),
            ),
            const SizedBox(height: 8),
            TextFormField(controller: item.hsnController, decoration: const InputDecoration(labelText: 'HSN Code (optional)', isDense: true)),
            const SizedBox(height: 8),
            Row(
              children: [
                Expanded(
                  child: TextFormField(
                    controller: item.qtyController,
                    keyboardType: TextInputType.number,
                    decoration: const InputDecoration(labelText: 'Qty *', isDense: true),
                    onChanged: (_) => setState(() {}),
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: DropdownButtonFormField<String>(
                    value: item.unit,
                    decoration: const InputDecoration(labelText: 'Unit', isDense: true),
                    items: ['Nos', 'Kg', 'L', 'M', 'Sq.Ft', 'Box', 'Hrs', 'Days']
                        .map((u) => DropdownMenuItem(value: u, child: Text(u))).toList(),
                    onChanged: (v) => setState(() => item.unit = v!),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 8),
            Row(
              children: [
                Expanded(
                  child: TextFormField(
                    controller: item.rateController,
                    keyboardType: TextInputType.number,
                    decoration: const InputDecoration(labelText: 'Rate (₹) *', isDense: true, prefixText: '₹ '),
                    onChanged: (_) => setState(() {}),
                  ),
                ),
                if (_applyGST) ...[
                  const SizedBox(width: 8),
                  Expanded(
                    child: DropdownButtonFormField<double>(
                      value: item.gstRate,
                      decoration: const InputDecoration(labelText: 'GST %', isDense: true),
                      items: [0, 5.0, 12.0, 18.0, 28.0]
                          .map((r) => DropdownMenuItem(value: r, child: Text('$r%'))).toList(),
                      onChanged: (v) => setState(() => item.gstRate = v!),
                    ),
                  ),
                ],
              ],
            ),
            if (item.amount > 0) ...[
              const SizedBox(height: 10),
              Container(
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  color: AppTheme.accent.withOpacity(0.05),
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(color: AppTheme.accent.withOpacity(0.2)),
                ),
                child: _applyGST
                    ? Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          _mini('Taxable', '₹ ${formatter.format(item.amount)}'),
                          _mini('GST (${item.gstRate}%)', '₹ ${formatter.format(item.gstAmount)}'),
                          _mini('Total', '₹ ${formatter.format(item.totalAmount)}', bold: true),
                        ],
                      )
                    : Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          _mini('Qty × Rate', '${item.qtyController.text} × ₹${item.rateController.text}'),
                          _mini('Amount', '₹ ${formatter.format(item.amount)}', bold: true),
                        ],
                      ),
              ),
            ],
          ],
        ),
      ),
    );
  }

  Widget _mini(String label, String value, {bool bold = false}) => Column(
    children: [
      Text(label, style: const TextStyle(fontSize: 10, color: AppTheme.textGrey)),
      Text(value, style: TextStyle(fontSize: 12, fontWeight: bold ? FontWeight.bold : FontWeight.w500, color: bold ? AppTheme.accent : AppTheme.textDark)),
    ],
  );

  Widget _buildSummaryCard() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: const Color(0xFFE2E8F0)),
        boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.04), blurRadius: 8)],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const Icon(Icons.receipt, color: AppTheme.accent, size: 18),
              const SizedBox(width: 8),
              const Text('Invoice Summary', style: TextStyle(fontWeight: FontWeight.bold, color: AppTheme.accent, fontSize: 15)),
              const Spacer(),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                decoration: BoxDecoration(
                  color: (_applyGST ? AppTheme.accent : Colors.grey).withOpacity(0.1),
                  borderRadius: BorderRadius.circular(20),
                ),
                child: Text(
                  _applyGST ? (_isInterState ? 'IGST' : 'CGST+SGST') : 'NO GST',
                  style: TextStyle(fontSize: 10, fontWeight: FontWeight.bold, color: _applyGST ? AppTheme.accent : Colors.grey[600]),
                ),
              ),
            ],
          ),
          const Divider(height: 20),
          _row('Subtotal', '₹ ${formatter.format(_subtotal)}'),
          if (_applyGST) ...[
            if (!_isInterState) ...[
              _row('CGST', '₹ ${formatter.format(_cgst)}'),
              _row('SGST', '₹ ${formatter.format(_sgst)}'),
            ] else
              _row('IGST', '₹ ${formatter.format(_igst)}'),
          ] else
            _row('GST', '₹ 0.00 (Not Applied)', grey: true),
          const Divider(height: 16),
          _row('TOTAL', '₹ ${formatter.format(_total)}', isTotal: true),
        ],
      ),
    );
  }

  Widget _row(String label, String value, {bool isTotal = false, bool grey = false}) => Padding(
    padding: const EdgeInsets.symmetric(vertical: 4),
    child: Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(label, style: TextStyle(fontWeight: isTotal ? FontWeight.bold : FontWeight.normal, fontSize: isTotal ? 16 : 14, color: isTotal ? AppTheme.accent : (grey ? AppTheme.textGrey : AppTheme.textDark))),
        Text(value, style: TextStyle(fontWeight: isTotal ? FontWeight.bold : FontWeight.normal, fontSize: isTotal ? 16 : 14, color: isTotal ? AppTheme.accent : (grey ? AppTheme.textGrey : AppTheme.textDark))),
      ],
    ),
  );

  Widget _datePicker(String label, DateTime value, Function(DateTime) onChanged) => GestureDetector(
    onTap: () async {
      final picked = await showDatePicker(context: context, initialDate: value, firstDate: DateTime(2020), lastDate: DateTime(2030));
      if (picked != null) onChanged(picked);
    },
    child: Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 14),
      decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(10), border: Border.all(color: const Color(0xFFE2E8F0))),
      child: Row(
        children: [
          const Icon(Icons.calendar_today, size: 16, color: AppTheme.accent),
          const SizedBox(width: 8),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(label, style: const TextStyle(fontSize: 10, color: AppTheme.textGrey)),
              Text(DateFormat('dd MMM yyyy').format(value), style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 13)),
            ],
          ),
        ],
      ),
    ),
  );

  Widget _sectionTitle(String title) => Text(title, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: AppTheme.primary));
}

class _ItemRow {
  final descriptionController = TextEditingController();
  final hsnController = TextEditingController();
  final qtyController = TextEditingController(text: '1');
  final rateController = TextEditingController();
  String unit = 'Nos';
  double gstRate = 18.0;

  double get amount => (double.tryParse(qtyController.text) ?? 0) * (double.tryParse(rateController.text) ?? 0);
  double get gstAmount => amount * gstRate / 100;
  double get totalAmount => amount + gstAmount;
}
