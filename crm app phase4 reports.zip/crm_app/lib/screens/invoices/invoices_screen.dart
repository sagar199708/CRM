import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../../models/invoice.dart';
import '../../services/database_service.dart';
import '../../utils/app_theme.dart';
import 'create_invoice_screen.dart';
import 'invoice_detail_screen.dart';

class InvoicesScreen extends StatefulWidget {
  const InvoicesScreen({super.key});

  @override
  State<InvoicesScreen> createState() => _InvoicesScreenState();
}

class _InvoicesScreenState extends State<InvoicesScreen> {
  List<Map<String, dynamic>> _invoices = [];
  bool _isLoading = true;
  String _filterStatus = 'all';

  final _statusColors = {
    'unpaid': AppTheme.warning,
    'paid': AppTheme.accent,
    'overdue': AppTheme.danger,
    'cancelled': Colors.grey,
  };

  final _statusIcons = {
    'unpaid': Icons.schedule,
    'paid': Icons.check_circle,
    'overdue': Icons.warning_rounded,
    'cancelled': Icons.cancel,
  };

  @override
  void initState() {
    super.initState();
    _loadInvoices();
  }

  Future<void> _loadInvoices() async {
    setState(() => _isLoading = true);
    // Auto-mark overdue
    final all = await DatabaseService.instance.getAllInvoices();
    for (final inv in all) {
      if (inv['status'] == 'unpaid' && DateTime.parse(inv['dueDate']).isBefore(DateTime.now())) {
        final updated = Map<String, dynamic>.from(inv);
        updated['status'] = 'overdue';
        await DatabaseService.instance.updateInvoice(updated);
      }
    }
    final data = await DatabaseService.instance.getAllInvoices();
    setState(() { _invoices = data; _isLoading = false; });
  }

  List<Map<String, dynamic>> get _filtered =>
      _filterStatus == 'all' ? _invoices : _invoices.where((i) => i['status'] == _filterStatus).toList();

  double get _totalPaid => _invoices.where((i) => i['status'] == 'paid').fold(0, (s, i) => s + (i['total'] as num).toDouble());
  double get _totalPending => _invoices.where((i) => i['status'] == 'unpaid' || i['status'] == 'overdue').fold(0, (s, i) => s + (i['total'] as num).toDouble());

  @override
  Widget build(BuildContext context) {
    final formatter = NumberFormat('#,##,##0.00', 'en_IN');
    return Scaffold(
      appBar: AppBar(
        title: const Text('Invoices'),
        actions: [
          IconButton(icon: const Icon(Icons.add), onPressed: () async {
            await Navigator.push(context, MaterialPageRoute(builder: (_) => const CreateInvoiceScreen()));
            _loadInvoices();
          }),
        ],
      ),
      body: Column(
        children: [
          // Stats bar
          Container(
            color: AppTheme.primary,
            padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
            child: Column(
              children: [
                Row(
                  children: [
                    Expanded(child: _statChip('Received', '₹ ${formatter.format(_totalPaid)}', AppTheme.accent)),
                    const SizedBox(width: 12),
                    Expanded(child: _statChip('Pending', '₹ ${formatter.format(_totalPending)}', AppTheme.warning)),
                  ],
                ),
                const SizedBox(height: 12),
                SingleChildScrollView(
                  scrollDirection: Axis.horizontal,
                  child: Row(
                    children: ['all', 'unpaid', 'paid', 'overdue', 'cancelled'].map((s) {
                      final sel = _filterStatus == s;
                      return Padding(
                        padding: const EdgeInsets.only(right: 8),
                        child: FilterChip(
                          label: Text(s.toUpperCase()),
                          selected: sel,
                          onSelected: (_) => setState(() => _filterStatus = s),
                          selectedColor: Colors.white,
                          backgroundColor: Colors.white.withOpacity(0.2),
                          labelStyle: TextStyle(color: sel ? AppTheme.primary : Colors.white, fontWeight: FontWeight.w600, fontSize: 11),
                          checkmarkColor: AppTheme.primary,
                        ),
                      );
                    }).toList(),
                  ),
                ),
              ],
            ),
          ),

          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
            child: Row(children: [Text('${_filtered.length} Invoices', style: const TextStyle(color: AppTheme.textGrey, fontWeight: FontWeight.w500))]),
          ),

          Expanded(
            child: _isLoading
                ? const Center(child: CircularProgressIndicator())
                : _filtered.isEmpty
                    ? _empty()
                    : RefreshIndicator(
                        onRefresh: _loadInvoices,
                        child: ListView.builder(
                          padding: const EdgeInsets.symmetric(horizontal: 16),
                          itemCount: _filtered.length,
                          itemBuilder: (ctx, i) => _invoiceCard(_filtered[i], formatter),
                        ),
                      ),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        backgroundColor: AppTheme.accent,
        onPressed: () async {
          await Navigator.push(context, MaterialPageRoute(builder: (_) => const CreateInvoiceScreen()));
          _loadInvoices();
        },
        child: const Icon(Icons.add, color: Colors.white),
      ),
    );
  }

  Widget _statChip(String label, String value, Color color) => Container(
    padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
    decoration: BoxDecoration(color: color.withOpacity(0.15), borderRadius: BorderRadius.circular(10), border: Border.all(color: color.withOpacity(0.4))),
    child: Row(
      children: [
        Icon(label == 'Received' ? Icons.check_circle : Icons.schedule, color: color, size: 18),
        const SizedBox(width: 8),
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(label, style: TextStyle(color: color, fontSize: 10, fontWeight: FontWeight.w600)),
            Text(value, style: TextStyle(color: color, fontSize: 13, fontWeight: FontWeight.bold)),
          ],
        ),
      ],
    ),
  );

  Widget _invoiceCard(Map<String, dynamic> inv, NumberFormat formatter) {
    final status = inv['status'] ?? 'unpaid';
    final color = _statusColors[status] ?? Colors.grey;
    final icon = _statusIcons[status] ?? Icons.receipt;
    final applyGST = inv['applyGST'] == 1;
    final date = DateTime.parse(inv['date']);
    final due = DateTime.parse(inv['dueDate']);

    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      child: InkWell(
        borderRadius: BorderRadius.circular(12),
        onTap: () async {
          await Navigator.push(context, MaterialPageRoute(builder: (_) => InvoiceDetailScreen(invoice: Invoice.fromMap(inv))));
          _loadInvoices();
        },
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(inv['invoiceNumber'] ?? '', style: const TextStyle(fontWeight: FontWeight.bold, color: AppTheme.accent, fontSize: 15)),
                  Row(
                    children: [
                      if (!applyGST)
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 2),
                          margin: const EdgeInsets.only(right: 6),
                          decoration: BoxDecoration(color: Colors.grey.withOpacity(0.1), borderRadius: BorderRadius.circular(20)),
                          child: const Text('NO GST', style: TextStyle(fontSize: 9, color: Colors.grey, fontWeight: FontWeight.bold)),
                        ),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                        decoration: BoxDecoration(color: color.withOpacity(0.1), borderRadius: BorderRadius.circular(20)),
                        child: Row(
                          children: [
                            Icon(icon, size: 11, color: color),
                            const SizedBox(width: 4),
                            Text(status.toUpperCase(), style: TextStyle(fontSize: 10, color: color, fontWeight: FontWeight.bold)),
                          ],
                        ),
                      ),
                    ],
                  ),
                ],
              ),
              const SizedBox(height: 8),
              Row(
                children: [
                  const Icon(Icons.person, size: 14, color: AppTheme.textGrey),
                  const SizedBox(width: 4),
                  Text(
                    inv['clientCompany'] != null && (inv['clientCompany'] as String).isNotEmpty
                        ? '${inv['clientName']} (${inv['clientCompany']})'
                        : inv['clientName'] ?? '',
                    style: const TextStyle(color: AppTheme.textGrey, fontSize: 13),
                  ),
                ],
              ),
              const SizedBox(height: 6),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('Issued: ${DateFormat('dd MMM yyyy').format(date)}', style: const TextStyle(color: AppTheme.textGrey, fontSize: 11)),
                      Text('Due: ${DateFormat('dd MMM yyyy').format(due)}',
                          style: TextStyle(color: status == 'overdue' ? AppTheme.danger : AppTheme.textGrey, fontSize: 11, fontWeight: status == 'overdue' ? FontWeight.bold : FontWeight.normal)),
                    ],
                  ),
                  Text('₹ ${formatter.format((inv['total'] as num).toDouble())}',
                      style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: AppTheme.textDark)),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _empty() => Center(
    child: Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Icon(Icons.receipt_long_outlined, size: 80, color: Colors.grey[300]),
        const SizedBox(height: 16),
        const Text('No invoices yet', style: TextStyle(fontSize: 18, color: AppTheme.textGrey)),
        const SizedBox(height: 8),
        const Text('Tap + to create your first invoice', style: TextStyle(color: AppTheme.textGrey)),
      ],
    ),
  );
}
