import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../../models/invoice.dart';
import '../../services/database_service.dart';
import '../../services/quotation_service.dart';
import '../../utils/app_theme.dart';

class InvoiceDetailScreen extends StatefulWidget {
  final Invoice invoice;
  const InvoiceDetailScreen({super.key, required this.invoice});

  @override
  State<InvoiceDetailScreen> createState() => _InvoiceDetailScreenState();
}

class _InvoiceDetailScreenState extends State<InvoiceDetailScreen> {
  late Invoice _invoice;
  final formatter = NumberFormat('#,##,##0.00', 'en_IN');
  final dateFormatter = DateFormat('dd MMM yyyy');

  final _statusColors = {
    'unpaid': AppTheme.warning,
    'paid': AppTheme.accent,
    'overdue': AppTheme.danger,
    'cancelled': Colors.grey,
  };

  @override
  void initState() {
    super.initState();
    _invoice = widget.invoice;
  }

  Future<void> _updateStatus(String s) async {
    final updated = _invoice.toMap();
    updated['status'] = s;
    await DatabaseService.instance.updateInvoice(updated);
    setState(() => _invoice = Invoice.fromMap(updated));
    if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Marked as $s!'), backgroundColor: AppTheme.accent));
  }

  Future<void> _delete() async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Delete Invoice'),
        content: const Text('Are you sure? This cannot be undone.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancel')),
          TextButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Delete', style: TextStyle(color: AppTheme.danger))),
        ],
      ),
    );
    if (ok == true) {
      await DatabaseService.instance.deleteInvoice(_invoice.id!);
      if (mounted) Navigator.pop(context);
    }
  }

  @override
  Widget build(BuildContext context) {
    final status = _invoice.status;
    final color = _statusColors[status] ?? Colors.grey;

    return Scaffold(
      appBar: AppBar(
        title: Text(_invoice.invoiceNumber),
        actions: [IconButton(icon: const Icon(Icons.delete), onPressed: _delete)],
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            // Header
            Container(
              color: AppTheme.accent,
              width: double.infinity,
              padding: const EdgeInsets.all(20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(_invoice.clientName, style: const TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold)),
                            if (_invoice.clientCompany != null) Text(_invoice.clientCompany!, style: TextStyle(color: Colors.white.withOpacity(0.8))),
                          ],
                        ),
                      ),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
                        decoration: BoxDecoration(color: color.withOpacity(0.2), borderRadius: BorderRadius.circular(20), border: Border.all(color: color)),
                        child: Text(status.toUpperCase(), style: TextStyle(color: color, fontWeight: FontWeight.bold, fontSize: 12)),
                      ),
                    ],
                  ),
                  const SizedBox(height: 12),
                  Row(
                    children: [
                      _hInfo('Date', dateFormatter.format(_invoice.date)),
                      const SizedBox(width: 20),
                      _hInfo('Due Date', dateFormatter.format(_invoice.dueDate)),
                      const SizedBox(width: 20),
                      _hInfo('Tax', _invoice.applyGST ? (_invoice.isInterState ? 'IGST' : 'CGST+SGST') : 'NO GST'),
                    ],
                  ),
                ],
              ),
            ),

            Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Amount card
                  Container(
                    width: double.infinity,
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      gradient: LinearGradient(colors: [AppTheme.accent, const Color(0xFF059669)]),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Column(
                      children: [
                        const Text('Invoice Total', style: TextStyle(color: Colors.white70, fontSize: 12)),
                        const SizedBox(height: 4),
                        Text('₹ ${formatter.format(_invoice.total)}',
                            style: const TextStyle(color: Colors.white, fontSize: 28, fontWeight: FontWeight.bold)),
                        Text(QuotationService.instance.numberToWords(_invoice.total),
                            style: TextStyle(color: Colors.white.withOpacity(0.8), fontSize: 10), textAlign: TextAlign.center),
                        if (!_invoice.applyGST)
                          Container(
                            margin: const EdgeInsets.only(top: 8),
                            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                            decoration: BoxDecoration(color: Colors.white.withOpacity(0.2), borderRadius: BorderRadius.circular(20)),
                            child: const Text('No GST Applied', style: TextStyle(color: Colors.white, fontSize: 11, fontWeight: FontWeight.bold)),
                          ),
                      ],
                    ),
                  ),

                  const SizedBox(height: 16),

                  // Status action buttons
                  if (status == 'unpaid' || status == 'overdue')
                    Row(
                      children: [
                        Expanded(
                          child: ElevatedButton.icon(
                            icon: const Icon(Icons.check_circle, size: 18),
                            label: const Text('Mark as PAID'),
                            style: ElevatedButton.styleFrom(backgroundColor: AppTheme.accent),
                            onPressed: () => _updateStatus('paid'),
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: OutlinedButton.icon(
                            icon: const Icon(Icons.cancel, size: 18),
                            label: const Text('Cancel'),
                            style: OutlinedButton.styleFrom(foregroundColor: Colors.grey),
                            onPressed: () => _updateStatus('cancelled'),
                          ),
                        ),
                      ],
                    ),
                  if (status == 'paid')
                    Container(
                      padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(color: AppTheme.accent.withOpacity(0.1), borderRadius: BorderRadius.circular(10), border: Border.all(color: AppTheme.accent.withOpacity(0.3))),
                      child: const Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(Icons.check_circle, color: AppTheme.accent),
                          SizedBox(width: 8),
                          Text('Payment Received', style: TextStyle(color: AppTheme.accent, fontWeight: FontWeight.bold, fontSize: 15)),
                        ],
                      ),
                    ),

                  const SizedBox(height: 20),

                  // Items
                  const Text('Items', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: AppTheme.primary)),
                  const SizedBox(height: 10),
                  Container(
                    decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(12), border: Border.all(color: const Color(0xFFE2E8F0))),
                    child: Column(
                      children: [
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                          decoration: const BoxDecoration(color: AppTheme.accent, borderRadius: BorderRadius.only(topLeft: Radius.circular(12), topRight: Radius.circular(12))),
                          child: Row(children: const [
                            Expanded(flex: 3, child: Text('Item', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 12))),
                            Expanded(child: Text('Qty', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 12), textAlign: TextAlign.center)),
                            Expanded(child: Text('Rate', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 12), textAlign: TextAlign.right)),
                            Expanded(child: Text('Total', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 12), textAlign: TextAlign.right)),
                          ]),
                        ),
                        ..._invoice.items.asMap().entries.map((e) {
                          final i = e.key; final item = e.value;
                          return Container(
                            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                            color: i % 2 == 0 ? Colors.white : const Color(0xFFF8FAFC),
                            child: Row(
                              children: [
                                Expanded(flex: 3, child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(item.description, style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 13)),
                                    if (item.hsnCode != null) Text('HSN: ${item.hsnCode}', style: const TextStyle(fontSize: 10, color: AppTheme.textGrey)),
                                    if (_invoice.applyGST) Text('GST: ${item.gstRate}%', style: const TextStyle(fontSize: 10, color: AppTheme.accent)),
                                    if (!_invoice.applyGST) const Text('No Tax', style: TextStyle(fontSize: 10, color: Colors.grey)),
                                  ],
                                )),
                                Expanded(child: Text('${item.quantity} ${item.unit}', textAlign: TextAlign.center, style: const TextStyle(fontSize: 12))),
                                Expanded(child: Text('₹ ${formatter.format(item.rate)}', textAlign: TextAlign.right, style: const TextStyle(fontSize: 12))),
                                Expanded(child: Text('₹ ${formatter.format(item.totalAmount)}', textAlign: TextAlign.right, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13))),
                              ],
                            ),
                          );
                        }),
                      ],
                    ),
                  ),

                  const SizedBox(height: 16),

                  // Totals
                  Container(
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(12), border: Border.all(color: const Color(0xFFE2E8F0))),
                    child: Column(
                      children: [
                        _tRow('Subtotal', '₹ ${formatter.format(_invoice.subtotal)}'),
                        if (_invoice.applyGST) ...[
                          if (!_invoice.isInterState) ...[
                            _tRow('CGST', '₹ ${formatter.format(_invoice.cgst)}'),
                            _tRow('SGST', '₹ ${formatter.format(_invoice.sgst)}'),
                          ] else
                            _tRow('IGST', '₹ ${formatter.format(_invoice.igst)}'),
                        ] else
                          _tRow('GST', '₹ 0.00 (Not Applied)', grey: true),
                        const Divider(),
                        _tRow('TOTAL', '₹ ${formatter.format(_invoice.total)}', isTotal: true),
                      ],
                    ),
                  ),

                  if (_invoice.notes != null) ...[
                    const SizedBox(height: 16),
                    Container(
                      width: double.infinity,
                      padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(color: const Color(0xFFFFFBEB), borderRadius: BorderRadius.circular(10), border: Border.all(color: const Color(0xFFFDE68A))),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Text('Notes', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 13)),
                          const SizedBox(height: 4),
                          Text(_invoice.notes!, style: const TextStyle(fontSize: 13)),
                        ],
                      ),
                    ),
                  ],
                  const SizedBox(height: 20),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _hInfo(String l, String v) => Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
    Text(l, style: TextStyle(color: Colors.white.withOpacity(0.7), fontSize: 10)),
    Text(v, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w600, fontSize: 12)),
  ]);

  Widget _tRow(String label, String value, {bool isTotal = false, bool grey = false}) => Padding(
    padding: const EdgeInsets.symmetric(vertical: 4),
    child: Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(label, style: TextStyle(fontWeight: isTotal ? FontWeight.bold : FontWeight.normal, fontSize: isTotal ? 16 : 14, color: isTotal ? AppTheme.accent : (grey ? AppTheme.textGrey : AppTheme.textDark))),
        Text(value, style: TextStyle(fontWeight: isTotal ? FontWeight.bold : FontWeight.normal, fontSize: isTotal ? 16 : 14, color: isTotal ? AppTheme.accent : (grey ? AppTheme.textGrey : AppTheme.textDark))),
      ],
    ),
  );
}
