import 'package:intl/intl.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';
import '../models/quotation.dart';

class QuotationService {
  static final QuotationService instance = QuotationService._();
  QuotationService._();

  // Generate next quotation number
  String generateQuotationNumber(int count) {
    final now = DateTime.now();
    final year = now.year.toString().substring(2);
    final month = now.month.toString().padLeft(2, '0');
    final number = (count + 1).toString().padLeft(3, '0');
    return 'QT-$year$month-$number';
  }

  // Calculate GST totals
  Map<String, double> calculateTotals(List<Map<String, dynamic>> items, bool isInterState) {
    double subtotal = 0;
    double totalGst = 0;

    for (final item in items) {
      final qty = (item['quantity'] as num).toDouble();
      final rate = (item['rate'] as num).toDouble();
      final gstRate = (item['gstRate'] as num).toDouble();
      final amount = qty * rate;
      subtotal += amount;
      totalGst += amount * gstRate / 100;
    }

    return {
      'subtotal': subtotal,
      'cgst': isInterState ? 0 : totalGst / 2,
      'sgst': isInterState ? 0 : totalGst / 2,
      'igst': isInterState ? totalGst : 0,
      'total': subtotal + totalGst,
    };
  }

  // Convert number to words (Indian system)
  String numberToWords(double amount) {
    final int rupees = amount.toInt();
    final int paise = ((amount - rupees) * 100).round();
    
    String words = _convertToWords(rupees);
    String result = '$words Rupees';
    if (paise > 0) {
      result += ' and ${_convertToWords(paise)} Paise';
    }
    result += ' Only';
    return result;
  }

  String _convertToWords(int number) {
    if (number == 0) return 'Zero';
    
    const ones = ['', 'One', 'Two', 'Three', 'Four', 'Five', 'Six', 'Seven', 'Eight', 'Nine',
      'Ten', 'Eleven', 'Twelve', 'Thirteen', 'Fourteen', 'Fifteen', 'Sixteen', 'Seventeen', 'Eighteen', 'Nineteen'];
    const tens = ['', '', 'Twenty', 'Thirty', 'Forty', 'Fifty', 'Sixty', 'Seventy', 'Eighty', 'Ninety'];

    if (number < 20) return ones[number];
    if (number < 100) return '${tens[number ~/ 10]}${number % 10 != 0 ? ' ${ones[number % 10]}' : ''}';
    if (number < 1000) return '${ones[number ~/ 100]} Hundred${number % 100 != 0 ? ' ${_convertToWords(number % 100)}' : ''}';
    if (number < 100000) return '${_convertToWords(number ~/ 1000)} Thousand${number % 1000 != 0 ? ' ${_convertToWords(number % 1000)}' : ''}';
    if (number < 10000000) return '${_convertToWords(number ~/ 100000)} Lakh${number % 100000 != 0 ? ' ${_convertToWords(number % 100000)}' : ''}';
    return '${_convertToWords(number ~/ 10000000)} Crore${number % 10000000 != 0 ? ' ${_convertToWords(number % 10000000)}' : ''}';
  }

  // Generate PDF
  Future<void> generateAndSharePDF(Quotation quotation, Map<String, String> companyInfo) async {
    final pdf = pw.Document();
    final formatter = NumberFormat('#,##,##0.00', 'en_IN');
    final dateFormatter = DateFormat('dd MMM yyyy');

    pdf.addPage(
      pw.MultiPage(
        pageFormat: PdfPageFormat.a4,
        margin: const pw.EdgeInsets.all(32),
        build: (context) => [
          // Header
          pw.Container(
            decoration: pw.BoxDecoration(
              color: PdfColor.fromHex('1E3A8A'),
              borderRadius: const pw.BorderRadius.all(pw.Radius.circular(8)),
            ),
            padding: const pw.EdgeInsets.all(20),
            child: pw.Row(
              mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
              children: [
                pw.Column(
                  crossAxisAlignment: pw.CrossAxisAlignment.start,
                  children: [
                    pw.Text(companyInfo['name'] ?? 'TECH SPWORLD',
                        style: pw.TextStyle(color: PdfColors.white, fontSize: 20, fontWeight: pw.FontWeight.bold)),
                    if ((companyInfo['tagline'] ?? '').isNotEmpty)
                      pw.Text(companyInfo['tagline']!, style: const pw.TextStyle(color: PdfColors.white60, fontSize: 9)),
                    pw.SizedBox(height: 4),
                    pw.Text(companyInfo['address'] ?? '', style: const pw.TextStyle(color: PdfColors.white70, fontSize: 10)),
                    pw.Text('${companyInfo['city']}, ${companyInfo['state']} - ${companyInfo['pincode']}',
                        style: const pw.TextStyle(color: PdfColors.white70, fontSize: 10)),
                    if ((companyInfo['gstin'] ?? '').isNotEmpty)
                      pw.Text('GSTIN: ${companyInfo['gstin']}', style: const pw.TextStyle(color: PdfColors.white70, fontSize: 10)),
                  ],
                ),
                pw.Column(
                  crossAxisAlignment: pw.CrossAxisAlignment.end,
                  children: [
                    pw.Text('QUOTATION', style: pw.TextStyle(color: PdfColors.white, fontSize: 22, fontWeight: pw.FontWeight.bold)),
                    pw.SizedBox(height: 4),
                    pw.Text(quotation.quotationNumber, style: const pw.TextStyle(color: PdfColors.white70, fontSize: 12)),
                  ],
                ),
              ],
            ),
          ),

          pw.SizedBox(height: 20),

          // Info Row
          pw.Row(
            crossAxisAlignment: pw.CrossAxisAlignment.start,
            children: [
              // Bill To
              pw.Expanded(
                child: pw.Container(
                  padding: const pw.EdgeInsets.all(12),
                  decoration: pw.BoxDecoration(
                    border: pw.Border.all(color: PdfColor.fromHex('E2E8F0')),
                    borderRadius: const pw.BorderRadius.all(pw.Radius.circular(8)),
                  ),
                  child: pw.Column(
                    crossAxisAlignment: pw.CrossAxisAlignment.start,
                    children: [
                      pw.Text('BILL TO', style: pw.TextStyle(fontSize: 9, fontWeight: pw.FontWeight.bold, color: PdfColor.fromHex('64748B'))),
                      pw.SizedBox(height: 6),
                      pw.Text(quotation.clientName, style: pw.TextStyle(fontSize: 13, fontWeight: pw.FontWeight.bold)),
                      if ((quotation.clientCompany ?? '').isNotEmpty)
                        pw.Text(quotation.clientCompany!, style: const pw.TextStyle(fontSize: 11)),
                    ],
                  ),
                ),
              ),
              pw.SizedBox(width: 16),
              // Dates
              pw.Expanded(
                child: pw.Container(
                  padding: const pw.EdgeInsets.all(12),
                  decoration: pw.BoxDecoration(
                    border: pw.Border.all(color: PdfColor.fromHex('E2E8F0')),
                    borderRadius: const pw.BorderRadius.all(pw.Radius.circular(8)),
                  ),
                  child: pw.Column(
                    crossAxisAlignment: pw.CrossAxisAlignment.start,
                    children: [
                      _pdfInfoRow('Date:', dateFormatter.format(quotation.date)),
                      _pdfInfoRow('Valid Until:', dateFormatter.format(quotation.validUntil)),
                      _pdfInfoRow('GST Type:', quotation.isInterState ? 'IGST (Inter-State)' : 'CGST+SGST (Intra-State)'),
                    ],
                  ),
                ),
              ),
            ],
          ),

          pw.SizedBox(height: 20),

          // Items Table
          pw.Table(
            border: pw.TableBorder.all(color: PdfColor.fromHex('E2E8F0'), width: 0.5),
            columnWidths: {
              0: const pw.FixedColumnWidth(25),
              1: const pw.FlexColumnWidth(3),
              2: const pw.FixedColumnWidth(45),
              3: const pw.FixedColumnWidth(45),
              4: const pw.FixedColumnWidth(45),
              5: const pw.FixedColumnWidth(40),
              6: const pw.FixedColumnWidth(60),
            },
            children: [
              // Header
              pw.TableRow(
                decoration: pw.BoxDecoration(color: PdfColor.fromHex('1E3A8A')),
                children: ['#', 'Description', 'HSN', 'Qty', 'Rate (₹)', 'GST%', 'Amount (₹)']
                    .map((h) => pw.Padding(
                          padding: const pw.EdgeInsets.all(8),
                          child: pw.Text(h, style: pw.TextStyle(color: PdfColors.white, fontSize: 9, fontWeight: pw.FontWeight.bold)),
                        ))
                    .toList(),
              ),
              // Items
              ...quotation.items.asMap().entries.map((entry) {
                final i = entry.key;
                final item = entry.value;
                final bg = i % 2 == 0 ? PdfColors.white : PdfColor.fromHex('F8FAFC');
                return pw.TableRow(
                  decoration: pw.BoxDecoration(color: bg),
                  children: [
                    _tableCell('${i + 1}'),
                    _tableCell(item.description),
                    _tableCell(item.hsnCode ?? '-'),
                    _tableCell('${item.quantity} ${item.unit}'),
                    _tableCell(formatter.format(item.rate)),
                    _tableCell('${item.gstRate}%'),
                    _tableCell(formatter.format(item.totalAmount), bold: true),
                  ],
                );
              }),
            ],
          ),

          pw.SizedBox(height: 12),

          // Totals
          pw.Row(
            crossAxisAlignment: pw.CrossAxisAlignment.start,
            children: [
              pw.Expanded(child: pw.SizedBox()),
              pw.Container(
                width: 220,
                child: pw.Column(
                  children: [
                    _totalRow('Subtotal', '₹ ${formatter.format(quotation.subtotal)}'),
                    if (!quotation.isInterState) ...[
                      _totalRow('CGST', '₹ ${formatter.format(quotation.cgst)}'),
                      _totalRow('SGST', '₹ ${formatter.format(quotation.sgst)}'),
                    ] else
                      _totalRow('IGST', '₹ ${formatter.format(quotation.igst)}'),
                    pw.Divider(color: PdfColor.fromHex('1E3A8A')),
                    _totalRow('TOTAL', '₹ ${formatter.format(quotation.total)}', isTotal: true),
                  ],
                ),
              ),
            ],
          ),

          pw.SizedBox(height: 12),

          // Amount in words
          pw.Container(
            padding: const pw.EdgeInsets.all(10),
            decoration: pw.BoxDecoration(
              color: PdfColor.fromHex('F0F9FF'),
              border: pw.Border.all(color: PdfColor.fromHex('BAE6FD')),
              borderRadius: const pw.BorderRadius.all(pw.Radius.circular(6)),
            ),
            child: pw.Row(
              children: [
                pw.Text('Amount in Words: ', style: pw.TextStyle(fontSize: 10, fontWeight: pw.FontWeight.bold)),
                pw.Expanded(child: pw.Text(numberToWords(quotation.total), style: const pw.TextStyle(fontSize: 10))),
              ],
            ),
          ),

          if ((quotation.notes ?? '').isNotEmpty) ...[
            pw.SizedBox(height: 12),
            pw.Text('Notes:', style: pw.TextStyle(fontWeight: pw.FontWeight.bold, fontSize: 11)),
            pw.Text(quotation.notes!, style: const pw.TextStyle(fontSize: 10)),
          ],

          pw.SizedBox(height: 30),

          // Footer
          pw.Row(
            mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
            children: [
              pw.Text('Thank you for your business!', style: const pw.TextStyle(fontSize: 10, color: PdfColors.grey)),
              pw.Column(
                crossAxisAlignment: pw.CrossAxisAlignment.center,
                children: [
                  pw.SizedBox(height: 40),
                  pw.Divider(width: 120),
                  pw.Text('Authorized Signature', style: const pw.TextStyle(fontSize: 9, color: PdfColors.grey)),
                ],
              ),
            ],
          ),
        ],
      ),
    );

    await Printing.sharePdf(bytes: await pdf.save(), filename: '${quotation.quotationNumber}.pdf');
  }

  pw.Widget _pdfInfoRow(String label, String value) {
    return pw.Padding(
      padding: const pw.EdgeInsets.only(bottom: 4),
      child: pw.Row(
        children: [
          pw.Text(label, style: pw.TextStyle(fontSize: 9, fontWeight: pw.FontWeight.bold, color: PdfColor.fromHex('64748B'))),
          pw.SizedBox(width: 4),
          pw.Text(value, style: const pw.TextStyle(fontSize: 9)),
        ],
      ),
    );
  }

  pw.Widget _tableCell(String text, {bool bold = false}) {
    return pw.Padding(
      padding: const pw.EdgeInsets.all(7),
      child: pw.Text(text, style: pw.TextStyle(fontSize: 9, fontWeight: bold ? pw.FontWeight.bold : pw.FontWeight.normal)),
    );
  }

  pw.Widget _totalRow(String label, String value, {bool isTotal = false}) {
    return pw.Padding(
      padding: const pw.EdgeInsets.symmetric(vertical: 3),
      child: pw.Row(
        mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
        children: [
          pw.Text(label,
              style: pw.TextStyle(
                fontSize: isTotal ? 12 : 10,
                fontWeight: isTotal ? pw.FontWeight.bold : pw.FontWeight.normal,
                color: isTotal ? PdfColor.fromHex('1E3A8A') : PdfColors.black,
              )),
          pw.Text(value,
              style: pw.TextStyle(
                fontSize: isTotal ? 12 : 10,
                fontWeight: isTotal ? pw.FontWeight.bold : pw.FontWeight.normal,
                color: isTotal ? PdfColor.fromHex('1E3A8A') : PdfColors.black,
              )),
        ],
      ),
    );
  }
}
