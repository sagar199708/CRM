import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';
import '../models/client.dart';

class DatabaseService {
  static final DatabaseService instance = DatabaseService._init();
  static Database? _database;

  DatabaseService._init();

  Future<Database> get database async {
    if (_database != null) return _database!;
    _database = await _initDB('crm.db');
    return _database!;
  }

  Future<Database> _initDB(String filePath) async {
    final dbPath = await getDatabasesPath();
    final path = join(dbPath, filePath);

    return await openDatabase(
      path,
      version: 1,
      onCreate: _createDB,
    );
  }

  Future _createDB(Database db, int version) async {
    await db.execute('''
      CREATE TABLE clients (
        id TEXT PRIMARY KEY,
        name TEXT NOT NULL,
        email TEXT NOT NULL,
        phone TEXT NOT NULL,
        address TEXT NOT NULL,
        city TEXT NOT NULL,
        state TEXT NOT NULL,
        pincode TEXT NOT NULL,
        gstin TEXT,
        companyName TEXT,
        createdAt TEXT NOT NULL
      )
    ''');

    await db.execute('''
      CREATE TABLE quotations (
        id TEXT PRIMARY KEY,
        clientId TEXT NOT NULL,
        quotationNumber TEXT NOT NULL,
        date TEXT NOT NULL,
        validUntil TEXT NOT NULL,
        items TEXT NOT NULL,
        subtotal REAL NOT NULL,
        cgst REAL NOT NULL,
        sgst REAL NOT NULL,
        igst REAL NOT NULL,
        total REAL NOT NULL,
        notes TEXT,
        status TEXT NOT NULL DEFAULT 'draft',
        createdAt TEXT NOT NULL,
        FOREIGN KEY (clientId) REFERENCES clients (id)
      )
    ''');

    await db.execute('''
      CREATE TABLE invoices (
        id TEXT PRIMARY KEY,
        clientId TEXT NOT NULL,
        invoiceNumber TEXT NOT NULL,
        date TEXT NOT NULL,
        dueDate TEXT NOT NULL,
        items TEXT NOT NULL,
        subtotal REAL NOT NULL,
        cgst REAL NOT NULL,
        sgst REAL NOT NULL,
        igst REAL NOT NULL,
        total REAL NOT NULL,
        notes TEXT,
        status TEXT NOT NULL DEFAULT 'unpaid',
        applyGST INTEGER NOT NULL DEFAULT 1,
        quotationId TEXT,
        createdAt TEXT NOT NULL,
        FOREIGN KEY (clientId) REFERENCES clients (id)
      )
    ''');

    await db.execute('''
      CREATE TABLE expenses (
        id TEXT PRIMARY KEY,
        title TEXT NOT NULL,
        amount REAL NOT NULL,
        category TEXT NOT NULL,
        date TEXT NOT NULL,
        notes TEXT,
        createdAt TEXT NOT NULL
      )
    ''');
    
    await db.execute('''
      CREATE TABLE IF NOT EXISTS company_settings (
        key TEXT PRIMARY KEY,
        value TEXT NOT NULL
      )
    ''');
  }

  // CLIENT CRUD
  Future<String> createClient(Client client) async {
    final db = await instance.database;
    await db.insert('clients', client.toMap());
    return client.id!;
  }

  Future<List<Client>> getAllClients() async {
    final db = await instance.database;
    final result = await db.query('clients', orderBy: 'createdAt DESC');
    return result.map((map) => Client.fromMap(map)).toList();
  }

  Future<Client?> getClient(String id) async {
    final db = await instance.database;
    final maps = await db.query('clients', where: 'id = ?', whereArgs: [id]);
    if (maps.isNotEmpty) return Client.fromMap(maps.first);
    return null;
  }

  Future<int> updateClient(Client client) async {
    final db = await instance.database;
    return await db.update(
      'clients',
      client.toMap(),
      where: 'id = ?',
      whereArgs: [client.id],
    );
  }

  Future<int> deleteClient(String id) async {
    final db = await instance.database;
    return await db.delete('clients', where: 'id = ?', whereArgs: [id]);
  }

  Future<List<Client>> searchClients(String query) async {
    final db = await instance.database;
    final result = await db.query(
      'clients',
      where: 'name LIKE ? OR email LIKE ? OR phone LIKE ? OR companyName LIKE ?',
      whereArgs: ['%$query%', '%$query%', '%$query%', '%$query%'],
    );
    return result.map((map) => Client.fromMap(map)).toList();
  }

  // QUOTATION CRUD
  Future<void> createQuotation(Map<String, dynamic> quotation) async {
    final db = await instance.database;
    await db.insert('quotations', quotation);
  }

  Future<List<Map<String, dynamic>>> getAllQuotations() async {
    final db = await instance.database;
    return await db.rawQuery('''
      SELECT q.*, c.name as clientName, c.companyName 
      FROM quotations q 
      LEFT JOIN clients c ON q.clientId = c.id 
      ORDER BY q.createdAt DESC
    ''');
  }

  Future<List<Map<String, dynamic>>> getClientQuotations(String clientId) async {
    final db = await instance.database;
    return await db.query('quotations', where: 'clientId = ?', whereArgs: [clientId], orderBy: 'createdAt DESC');
  }

  Future<int> updateQuotation(Map<String, dynamic> quotation) async {
    final db = await instance.database;
    return await db.update('quotations', quotation, where: 'id = ?', whereArgs: [quotation['id']]);
  }

  Future<int> deleteQuotation(String id) async {
    final db = await instance.database;
    return await db.delete('quotations', where: 'id = ?', whereArgs: [id]);
  }

  // INVOICE CRUD
  Future<void> createInvoice(Map<String, dynamic> invoice) async {
    final db = await instance.database;
    await db.insert('invoices', invoice);
  }

  Future<List<Map<String, dynamic>>> getAllInvoices() async {
    final db = await instance.database;
    return await db.rawQuery('''
      SELECT i.*, c.name as clientName, c.companyName 
      FROM invoices i 
      LEFT JOIN clients c ON i.clientId = c.id 
      ORDER BY i.createdAt DESC
    ''');
  }

  Future<int> updateInvoice(Map<String, dynamic> invoice) async {
    final db = await instance.database;
    return await db.update('invoices', invoice, where: 'id = ?', whereArgs: [invoice['id']]);
  }

  Future<int> deleteInvoice(String id) async {
    final db = await instance.database;
    return await db.delete('invoices', where: 'id = ?', whereArgs: [id]);
  }

  // EXPENSE CRUD
  Future<void> createExpense(Map<String, dynamic> expense) async {
    final db = await instance.database;
    await db.insert('expenses', expense);
  }

  Future<List<Map<String, dynamic>>> getAllExpenses() async {
    final db = await instance.database;
    return await db.query('expenses', orderBy: 'date DESC');
  }

  Future<int> updateExpense(Map<String, dynamic> expense) async {
    final db = await instance.database;
    return await db.update('expenses', expense, where: 'id = ?', whereArgs: [expense['id']]);
  }

  Future<int> deleteExpense(String id) async {
    final db = await instance.database;
    return await db.delete('expenses', where: 'id = ?', whereArgs: [id]);
  }

  // REPORTS
  Future<Map<String, dynamic>> getSalesReport({String? month, String? year}) async {
    final db = await instance.database;

    String whereClause = '';
    List<dynamic> args = [];

    if (month != null && year != null) {
      whereClause = "WHERE strftime('%m', date) = ? AND strftime('%Y', date) = ?";
      args = [month.padLeft(2, '0'), year];
    } else if (year != null) {
      whereClause = "WHERE strftime('%Y', date) = ?";
      args = [year];
    }

    final invoiceTotal = await db.rawQuery(
      "SELECT SUM(total) as total, COUNT(*) as count FROM invoices $whereClause AND status != 'cancelled'".replaceFirst('AND', whereClause.isEmpty ? 'WHERE' : 'AND'),
      args,
    );

    final paidTotal = await db.rawQuery(
      "SELECT SUM(total) as total FROM invoices $whereClause ${whereClause.isEmpty ? 'WHERE' : 'AND'} status = 'paid'",
      [...args, ...args.isEmpty ? [] : []],
    );

    return {
      'totalInvoiced': invoiceTotal.first['total'] ?? 0.0,
      'totalInvoices': invoiceTotal.first['count'] ?? 0,
      'totalPaid': paidTotal.first['total'] ?? 0.0,
    };
  }

  Future<void> close() async {
    final db = await instance.database;
    db.close();
  }
}
