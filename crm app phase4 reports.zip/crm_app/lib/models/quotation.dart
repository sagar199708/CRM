import 'dart:convert';

class QuotationItem {
  final String description;
  final String? hsnCode;
  final double quantity;
  final String unit;
  final double rate;
  final double gstRate;
  final double amount;

  QuotationItem({
    required this.description,
    this.hsnCode,
    required this.quantity,
    required this.unit,
    required this.rate,
    required this.gstRate,
  }) : amount = quantity * rate;

  double get taxableAmount => amount;
  double get gstAmount => amount * gstRate / 100;
  double get totalAmount => amount + gstAmount;

  Map<String, dynamic> toMap() => {
    'description': description,
    'hsnCode': hsnCode,
    'quantity': quantity,
    'unit': unit,
    'rate': rate,
    'gstRate': gstRate,
    'amount': amount,
  };

  factory QuotationItem.fromMap(Map<String, dynamic> map) => QuotationItem(
    description: map['description'],
    hsnCode: map['hsnCode'],
    quantity: (map['quantity'] as num).toDouble(),
    unit: map['unit'],
    rate: (map['rate'] as num).toDouble(),
    gstRate: (map['gstRate'] as num).toDouble(),
  );
}

class Quotation {
  final String? id;
  final String clientId;
  final String clientName;
  final String? clientCompany;
  final String quotationNumber;
  final DateTime date;
  final DateTime validUntil;
  final List<QuotationItem> items;
  final double subtotal;
  final double cgst;
  final double sgst;
  final double igst;
  final double total;
  final String? notes;
  final String status; // draft, sent, accepted, rejected
  final bool isInterState; // determines IGST vs CGST+SGST
  final DateTime createdAt;

  Quotation({
    this.id,
    required this.clientId,
    required this.clientName,
    this.clientCompany,
    required this.quotationNumber,
    required this.date,
    required this.validUntil,
    required this.items,
    required this.subtotal,
    required this.cgst,
    required this.sgst,
    required this.igst,
    required this.total,
    this.notes,
    this.status = 'draft',
    this.isInterState = false,
    DateTime? createdAt,
  }) : createdAt = createdAt ?? DateTime.now();

  Map<String, dynamic> toMap() => {
    'id': id,
    'clientId': clientId,
    'clientName': clientName,
    'clientCompany': clientCompany,
    'quotationNumber': quotationNumber,
    'date': date.toIso8601String(),
    'validUntil': validUntil.toIso8601String(),
    'items': jsonEncode(items.map((e) => e.toMap()).toList()),
    'subtotal': subtotal,
    'cgst': cgst,
    'sgst': sgst,
    'igst': igst,
    'total': total,
    'notes': notes,
    'status': status,
    'isInterState': isInterState ? 1 : 0,
    'createdAt': createdAt.toIso8601String(),
  };

  factory Quotation.fromMap(Map<String, dynamic> map) {
    final itemsList = jsonDecode(map['items'] as String) as List;
    return Quotation(
      id: map['id'],
      clientId: map['clientId'],
      clientName: map['clientName'] ?? '',
      clientCompany: map['clientCompany'],
      quotationNumber: map['quotationNumber'],
      date: DateTime.parse(map['date']),
      validUntil: DateTime.parse(map['validUntil']),
      items: itemsList.map((e) => QuotationItem.fromMap(e)).toList(),
      subtotal: (map['subtotal'] as num).toDouble(),
      cgst: (map['cgst'] as num).toDouble(),
      sgst: (map['sgst'] as num).toDouble(),
      igst: (map['igst'] as num).toDouble(),
      total: (map['total'] as num).toDouble(),
      notes: map['notes'],
      status: map['status'] ?? 'draft',
      isInterState: map['isInterState'] == 1,
      createdAt: DateTime.parse(map['createdAt']),
    );
  }
}
