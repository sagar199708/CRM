class Expense {
  final String? id;
  final String title;
  final double amount;
  final String category;
  final DateTime date;
  final String? notes;
  final DateTime createdAt;

  Expense({
    this.id,
    required this.title,
    required this.amount,
    required this.category,
    required this.date,
    this.notes,
    DateTime? createdAt,
  }) : createdAt = createdAt ?? DateTime.now();

  Map<String, dynamic> toMap() => {
    'id': id,
    'title': title,
    'amount': amount,
    'category': category,
    'date': date.toIso8601String(),
    'notes': notes,
    'createdAt': createdAt.toIso8601String(),
  };

  factory Expense.fromMap(Map<String, dynamic> m) => Expense(
    id: m['id'],
    title: m['title'],
    amount: (m['amount'] as num).toDouble(),
    category: m['category'],
    date: DateTime.parse(m['date']),
    notes: m['notes'],
    createdAt: DateTime.parse(m['createdAt']),
  );

  static const List<String> categories = [
    'Office Supplies', 'Travel', 'Marketing', 'Utilities',
    'Rent', 'Software', 'Equipment', 'Salaries', 'Food',
    'Maintenance', 'Miscellaneous',
  ];

  static const Map<String, String> categoryIcons = {
    'Office Supplies': '🖊️',
    'Travel': '✈️',
    'Marketing': '📢',
    'Utilities': '💡',
    'Rent': '🏢',
    'Software': '💻',
    'Equipment': '🔧',
    'Salaries': '👥',
    'Food': '🍽️',
    'Maintenance': '🔨',
    'Miscellaneous': '📦',
  };
}
