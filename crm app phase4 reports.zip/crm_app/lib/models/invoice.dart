import 'dart:convert';

class InvoiceItem {
  final String description;
  final String? hsnCode;
  final double quantity;
  final String unit;
  final double rate;
  final double gstRate;
  final double amount;

  InvoiceItem({
    required this.description,
    this.hsnCode,
    required this.quantity,
    required this.unit,
    required this.rate,
    required this.gstRate,
  }) : amount = quantity * rate;

  double get gstAmount => amount * gstRate / 100;
  double get totalAmount => amount + gstAmount;

  Map<String, dynamic> toMap() => {
    'description': description, 'hsnCode': hsnCode,
    'quantity': quantity, 'unit': unit,
    'rate': rate, 'gstRate': gstRate, 'amount': amount,
  };

  factory InvoiceItem.fromMap(Map<String, dynamic> m) => InvoiceItem(
    description: m['description'], hsnCode: m['hsnCode'],
    quantity: (m['quantity'] as num).toDouble(),
    unit: m['unit'], rate: (m['rate'] as num).toDouble(),
    gstRate: (m['gstRate'] as num).toDouble(),
  );
}

class Invoice {
  final String? id;
  final String clientId;
  final String clientName;
  final String? clientCompany;
  final String invoiceNumber;
  final DateTime date;
  final DateTime dueDate;
  final List<InvoiceItem> items;
  final double subtotal;
  final double cgst;
  final double sgst;
  final double igst;
  final double total;
  final String? notes;
  final String status; // unpaid, paid, overdue, cancelled
  final bool isInterState;
  final bool applyGST;
  final String? quotationId;
  final DateTime createdAt;

  Invoice({
    this.id,
    required this.clientId,
    required this.clientName,
    this.clientCompany,
    required this.invoiceNumber,
    required this.date,
    required this.dueDate,
    required this.items,
    required this.subtotal,
    required this.cgst,
    required this.sgst,
    required this.igst,
    required this.total,
    this.notes,
    this.status = 'unpaid',
    this.isInterState = false,
    this.applyGST = true,
    this.quotationId,
    DateTime? createdAt,
  }) : createdAt = createdAt ?? DateTime.now();

  Map<String, dynamic> toMap() => {
    'id': id, 'clientId': clientId,
    'clientName': clientName, 'clientCompany': clientCompany,
    'invoiceNumber': invoiceNumber,
    'date': date.toIso8601String(),
    'dueDate': dueDate.toIso8601String(),
    'items': jsonEncode(items.map((e) => e.toMap()).toList()),
    'subtotal': subtotal, 'cgst': cgst, 'sgst': sgst, 'igst': igst, 'total': total,
    'notes': notes, 'status': status,
    'isInterState': isInterState ? 1 : 0,
    'applyGST': applyGST ? 1 : 0,
    'quotationId': quotationId,
    'createdAt': createdAt.toIso8601String(),
  };

  factory Invoice.fromMap(Map<String, dynamic> m) {
    final itemsList = jsonDecode(m['items'] as String) as List;
    return Invoice(
      id: m['id'], clientId: m['clientId'],
      clientName: m['clientName'] ?? '',
      clientCompany: m['clientCompany'],
      invoiceNumber: m['invoiceNumber'],
      date: DateTime.parse(m['date']),
      dueDate: DateTime.parse(m['dueDate']),
      items: itemsList.map((e) => InvoiceItem.fromMap(e)).toList(),
      subtotal: (m['subtotal'] as num).toDouble(),
      cgst: (m['cgst'] as num).toDouble(),
      sgst: (m['sgst'] as num).toDouble(),
      igst: (m['igst'] as num).toDouble(),
      total: (m['total'] as num).toDouble(),
      notes: m['notes'], status: m['status'] ?? 'unpaid',
      isInterState: m['isInterState'] == 1,
      applyGST: m['applyGST'] == 1,
      quotationId: m['quotationId'],
      createdAt: DateTime.parse(m['createdAt']),
    );
  }
}
